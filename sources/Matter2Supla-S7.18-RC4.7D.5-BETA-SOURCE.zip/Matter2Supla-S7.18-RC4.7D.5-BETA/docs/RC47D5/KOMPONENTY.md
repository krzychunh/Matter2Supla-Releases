# Komponenty rejestru Espressif dla wydania RC4.7D.5

Lista odpowiada plikowi `dependencies.lock.in`. Menedżer ESP-IDF pobiera pakiety z wymienionych wersji i sprawdza ich sumy. Na stronie każdej wersji dostępne są pliki publikowane przez dostawcę komponentu. Źródła lokalnych komponentów ESP-IDF są w rewizji SDK podanej w głównym README.

| Komponent | Wersja |
| --- | --- |
| chmorgan/esp-libhelix-mp3 | [1.0.3](https://components.espressif.com/components/chmorgan/esp-libhelix-mp3/versions/1.0.3) |
| esp-qa/coexist-cmd | [0.0.2](https://components.espressif.com/components/esp-qa/coexist-cmd/versions/0.0.2) |
| espressif/arduino-esp32 | [3.3.12](https://components.espressif.com/components/espressif/arduino-esp32/versions/3.3.12) |
| espressif/cbor | [0.6.1~4](https://components.espressif.com/components/espressif/cbor/versions/0.6.1~4) |
| espressif/cjson | [1.7.19~2](https://components.espressif.com/components/espressif/cjson/versions/1.7.19~2) |
| espressif/esp-dsp | [1.8.2](https://components.espressif.com/components/espressif/esp-dsp/versions/1.8.2) |
| espressif/esp-modbus | [2.1.4](https://components.espressif.com/components/espressif/esp-modbus/versions/2.1.4) |
| espressif/esp-serial-flasher | [0.0.11](https://components.espressif.com/components/espressif/esp-serial-flasher/versions/0.0.11) |
| espressif/esp-zboss-lib | [1.6.4](https://components.espressif.com/components/espressif/esp-zboss-lib/versions/1.6.4) |
| espressif/esp-zigbee-lib | [1.6.8](https://components.espressif.com/components/espressif/esp-zigbee-lib/versions/1.6.8) |
| espressif/esp_daylight | [1.0.1](https://components.espressif.com/components/espressif/esp_daylight/versions/1.0.1) |
| espressif/esp_delta_ota | [1.1.4](https://components.espressif.com/components/espressif/esp_delta_ota/versions/1.1.4) |
| espressif/esp_diag_data_store | [1.1.1](https://components.espressif.com/components/espressif/esp_diag_data_store/versions/1.1.1) |
| espressif/esp_diagnostics | [1.3.4](https://components.espressif.com/components/espressif/esp_diagnostics/versions/1.3.4) |
| espressif/esp_encrypted_img | [2.3.0](https://components.espressif.com/components/espressif/esp_encrypted_img/versions/2.3.0) |
| espressif/esp_insights | [1.3.4](https://components.espressif.com/components/espressif/esp_insights/versions/1.3.4) |
| espressif/esp_modem | [2.1.0](https://components.espressif.com/components/espressif/esp_modem/versions/2.1.0) |
| espressif/esp_ot_cli_extension | [2.0.3](https://components.espressif.com/components/espressif/esp_ot_cli_extension/versions/2.0.3) |
| espressif/esp_rainmaker | [1.17.0](https://components.espressif.com/components/espressif/esp_rainmaker/versions/1.17.0) |
| espressif/esp_rcp_update | [1.3.1](https://components.espressif.com/components/espressif/esp_rcp_update/versions/1.3.1) |
| espressif/esp_schedule | [1.3.3](https://components.espressif.com/components/espressif/esp_schedule/versions/1.3.3) |
| espressif/esp_secure_cert_mgr | [2.9.3](https://components.espressif.com/components/espressif/esp_secure_cert_mgr/versions/2.9.3) |
| espressif/iperf | [1.0.3](https://components.espressif.com/components/espressif/iperf/versions/1.0.3) |
| espressif/iperf-cmd | [1.0.3](https://components.espressif.com/components/espressif/iperf-cmd/versions/1.0.3) |
| espressif/jsmn | [1.1.0](https://components.espressif.com/components/espressif/jsmn/versions/1.1.0) |
| espressif/json_generator | [1.1.2](https://components.espressif.com/components/espressif/json_generator/versions/1.1.2) |
| espressif/json_parser | [1.0.3](https://components.espressif.com/components/espressif/json_parser/versions/1.0.3) |
| espressif/led_strip | [2.5.5](https://components.espressif.com/components/espressif/led_strip/versions/2.5.5) |
| espressif/libsodium | [1.0.22~1](https://components.espressif.com/components/espressif/libsodium/versions/1.0.22~1) |
| espressif/mdns | [1.14.1](https://components.espressif.com/components/espressif/mdns/versions/1.14.1) |
| espressif/mqtt | [1.0.0](https://components.espressif.com/components/espressif/mqtt/versions/1.0.0) |
| espressif/network_provisioning | [1.0.2](https://components.espressif.com/components/espressif/network_provisioning/versions/1.0.2) |
| espressif/qrcode | [0.1.0~2](https://components.espressif.com/components/espressif/qrcode/versions/0.1.0~2) |
| espressif/rmaker_cmd_resp | [1.0.0](https://components.espressif.com/components/espressif/rmaker_cmd_resp/versions/1.0.0) |
| espressif/rmaker_common | [1.9.0](https://components.espressif.com/components/espressif/rmaker_common/versions/1.9.0) |
| espressif/rmaker_common_events | [1.1.0](https://components.espressif.com/components/espressif/rmaker_common_events/versions/1.1.0) |
| espressif/rmaker_console | [1.0.1](https://components.espressif.com/components/espressif/rmaker_console/versions/1.0.1) |
| espressif/rmaker_system_ctrl | [1.0.0](https://components.espressif.com/components/espressif/rmaker_system_ctrl/versions/1.0.0) |
| espressif/rmaker_time_sync | [1.0.2](https://components.espressif.com/components/espressif/rmaker_time_sync/versions/1.0.2) |
| espressif/rmaker_work_queue | [1.0.0](https://components.espressif.com/components/espressif/rmaker_work_queue/versions/1.0.0) |
| joltwallet/littlefs | [1.23.1](https://components.espressif.com/components/joltwallet/littlefs/versions/1.23.1) |
