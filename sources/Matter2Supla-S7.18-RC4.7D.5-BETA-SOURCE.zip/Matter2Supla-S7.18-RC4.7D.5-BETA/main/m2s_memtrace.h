#pragma once
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

// Called from existing ESP-IDF allocation-failure hook.
// No logging, dynamic allocation, heap inspection or blocking waits.
void m2s_memtrace_record(size_t requested_size, uint32_t caps, const char *function_name);

// Called from the existing network worker (not from the failure hook).
void m2s_memtrace_tick(void);

// M2S-S717-RC31-MEMTRACE-HTTP: non-destructive memory trace snapshot.
// A read never clears the ring. api points to a persistent ESP-IDF function name.
#define M2S_MEMTRACE_MAX_EVENTS 16
typedef struct {
    uint32_t seq;
    uint32_t size;
    uint32_t caps;
    int64_t event_us;
    const char *api;
    char task_name[16]; // copied inside failure hook, or ISR/unknown
    uint8_t isr;
    int64_t pre_probe_us; // last periodic sample BEFORE this failure, not exact failure instant
    uint32_t pre_caps_free_bytes;
    uint32_t pre_caps_largest_bytes;
} m2s_memtrace_event_t;
typedef struct {
    uint32_t recorded_total;
    uint32_t drained_total;
    uint32_t contention_drops;
    uint32_t tick_calls;
    uint32_t event_count;
    m2s_memtrace_event_t events[M2S_MEMTRACE_MAX_EVENTS];
} m2s_memtrace_snapshot_t;
// false: trace lock temporarily busy; retry GET. Never blocks allocator callback.
bool m2s_memtrace_snapshot(m2s_memtrace_snapshot_t *out);
// M2S-S717-RC32-ALLOC-CONTEXT - pre_caps means MALLOC_CAP_INTERNAL|MALLOC_CAP_DMA|MALLOC_CAP_8BIT.
// A periodic sample may MISS momentary heap exhaustion between ticks.


#ifdef __cplusplus
}
#endif
