#include <openthread/thread_ftd.h>
#include "m2s_readings.h"
#include "m2s_supla.h"
#include <openthread/srp_server.h>
#include <cstring>
extern "C" uint8_t m2s_supla_recovery_hint(uint32_t node);
#include "m2s_ikea_catalog.h"
#include "m2s_matter_api.h"
#include "m2s_ble_scan.h"
#include "freertos/FreeRTOS.h"
#include "esp_timer.h"
#include <esp_matter_controller_read_command.h>
#include <esp_matter_controller_subscribe_command.h>
#include <platform/CHIPDeviceLayer.h>
#include <utility>
#include <cmath>
#include <cstdio>
#include <atomic>
#include "nvs.h"
#include "m2s_devices.h"
#include "m2s_network.h"
#include "esp_heap_caps.h"
#include "esp_log.h"
#include "esp_openthread.h"
#include "esp_openthread_lock.h"
#include <openthread/thread.h>

namespace {
portMUX_TYPE mux = portMUX_INITIALIZER_UNLOCKED;
// Independent per-request state. Slot ownership lasts until SDK completion/destruction.
struct ReadFlight { m2s_readings_t report; bool battery; uint8_t hint; int64_t previous_due; int64_t previous_battery_due; };
ReadFlight flights[2]{};
m2s_readings_t last_snapshot{};
unsigned active_reads_locked(){return unsigned(flights[0].report.busy)+unsigned(flights[1].report.busy);}
bool node_busy_locked(uint32_t node){for(const auto &f:flights)if(f.report.busy && f.report.node==node)return true;return false;}
bool parallel_headroom(){
 return heap_caps_get_free_size(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT)>=48000 &&
        heap_caps_get_free_size(MALLOC_CAP_DMA)>=32000 &&
        heap_caps_get_largest_free_block(MALLOC_CAP_DMA)>=20480;
}
struct Cached {
    uint32_t node;
    int64_t next_us;
    int64_t next_battery_us;
    uint16_t interval_minutes;
    m2s_readings_t report;
    // Volatile status of one combined temperature+humidity Matter subscription.
    bool sub_requested;
    bool sub_reporting;
    int64_t sub_requested_us;
    int64_t sub_report_us;
    uint32_t sub_report_count;
    // Bounded recovery after subscription termination; not persisted to NVS.
    int64_t sub_retry_after_us;
    uint8_t read_failures; // volatile, bounded recovery attempts for unavailable Matter nodes
};
Cached *cache=nullptr;
int64_t next_dispatch=0;
int64_t get_next_dispatch(){portENTER_CRITICAL(&mux);const int64_t value=next_dispatch;portEXIT_CRITICAL(&mux);return value;}
void set_next_dispatch(int64_t value){portENTER_CRITICAL(&mux);next_dispatch=value;portEXIT_CRITICAL(&mux);}
unsigned cursor=0;

std::atomic_bool readings_paused{false}; // S7.9 runtime-only, defaults to running
constexpr int64_t kSubscriptionRetryUs=900000000LL; // Healthy-subscription liveness check (15 min).
constexpr int64_t kMotionEstablishRetryUs=60000000LL; // Motion: retry incomplete CASE/Subscribe after 60 s.
constexpr int64_t kSubTerminationCooldownUs=30000000LL; // Avoid a fast retry loop when node is asleep.
constexpr uint16_t kSubscriptionMinSeconds=15;
constexpr uint16_t kSubscriptionMaxSeconds=300;
constexpr int64_t kFastFallbackPollUs=30000000LL; // 30 seconds, only when no live subscription
constexpr int64_t kStartupDispatchUs=500000LL;
constexpr int64_t kFastDispatchUs=3000000LL; // stagger commands: do not overload sleepy Thread nodes
constexpr int64_t kInitialDispatchUs=0LL; // readiness is still checked in tick()
constexpr int64_t kRecoveryDelaysUs[]={5000000LL,10000000LL,20000000LL,30000000LL,60000000LL};
constexpr int64_t kBatteryIntervalUs=3600000000LL;
constexpr int64_t kBatteryRetryUs=300000000LL;
constexpr uint16_t kDefaultIntervalMinutes=1;
constexpr uint16_t kMinIntervalMinutes=1;
constexpr uint16_t kMaxIntervalMinutes=1440;
constexpr const char *kPollNamespace="m2s_poll9";
constexpr int64_t interval_us(uint16_t minutes){
  return static_cast<int64_t>(minutes)*60LL*1000000LL;
}
void poll_key(uint32_t node,char (&key)[12]){
  snprintf(key,sizeof(key),"n%05lu",static_cast<unsigned long>(node));
}
uint16_t load_interval_nvs(uint32_t node){
  if(node<1 || node>65535)return kDefaultIntervalMinutes;
  nvs_handle_t nvs=0;
  if(nvs_open(kPollNamespace,NVS_READONLY,&nvs)!=ESP_OK)return kDefaultIntervalMinutes;
  char key[12]{};poll_key(node,key);
  uint16_t minutes=kDefaultIntervalMinutes;
  esp_err_t result=nvs_get_u16(nvs,key,&minutes);
  nvs_close(nvs);
  if(result!=ESP_OK || minutes<kMinIntervalMinutes || minutes>kMaxIntervalMinutes)
    return kDefaultIntervalMinutes;
  return minutes;
}
// Caller holds mux; fixed allocation in PSRAM, never written to NVS.
void cache_finish(const m2s_readings_t &snapshot){
 if(!cache)return;
 for(int i=0;i<M2S_DEVICE_LIMIT;i++)if(cache[i].node==snapshot.node){
   const auto previous=cache[i].report;
   cache[i].report=snapshot;
   // A subscription report can arrive WHILE a periodic ReadClient is active.
   // Never replace a newer subscribed contact state with that in-flight read.
   // Preserve timestamps: the previous cache value is not a fresh sample.
   const M2sIkeaSensor cached_model=(previous.vendor_valid && previous.product_valid)?
     m2s_ikea_sensor(previous.vendor_id,previous.product_id):M2sIkeaSensor::Unknown;
   const bool binary_subscription=cache[i].sub_reporting &&
     (cached_model==M2sIkeaSensor::Contact ||
      cached_model==M2sIkeaSensor::Motion ||
      cached_model==M2sIkeaSensor::WaterLeak);
   const uint32_t binary_cluster=(cached_model==M2sIkeaSensor::Motion)?0x0406:0x0045;
   for(int j=0;j<previous.count;j++){
     const auto &old=previous.values[j];
     int index=0;
     for(;index<cache[i].report.count;index++)
       if(cache[i].report.values[index].endpoint==old.endpoint &&
          cache[i].report.values[index].cluster==old.cluster)break;
     if(index<cache[i].report.count){
       if(binary_subscription && old.cluster==binary_cluster &&
          old.received_us>=snapshot.started_us && old.received_us>0)
         cache[i].report.values[index]=old;
     }else if(index<8 && (snapshot.state>=3 ||
                         (binary_subscription && old.cluster==binary_cluster))){
       cache[i].report.values[cache[i].report.count++]=old;
     }
   }
   // Temperature/humidity poll usually does not query battery. Preserve its
   // last timestamp instead of making a cached reading look freshly sampled.
   if(!snapshot.battery_valid){
     cache[i].report.battery_raw=previous.battery_raw;
     cache[i].report.battery_valid=previous.battery_valid;
     cache[i].report.battery_received_us=previous.battery_received_us;
   }else{
     cache[i].next_battery_us=esp_timer_get_time()+kBatteryIntervalUs;
   }
   if(!snapshot.vendor_valid){cache[i].report.vendor_id=previous.vendor_id;cache[i].report.vendor_valid=previous.vendor_valid;}
   if(!snapshot.product_valid){cache[i].report.product_id=previous.product_id;cache[i].report.product_valid=previous.product_valid;}
   // RC4.5: The first unknown-model request reads identity and generic T/H.
   // Once the model is known, schedule one prompt model-specific read instead
   // of waiting for the normal 30/60-second polling interval. Keep a single
   // active CHIP request, the existing 3-second dispatch gap and failure backoff.
   const bool identity_just_resolved=(!previous.vendor_valid || !previous.product_valid) &&
       cache[i].report.vendor_valid && cache[i].report.product_valid;
   const M2sIkeaSensor resolved_model=identity_just_resolved ?
       m2s_ikea_sensor(cache[i].report.vendor_id,cache[i].report.product_id) :
       M2sIkeaSensor::Unknown;
   bool needs_model_read=resolved_model==M2sIkeaSensor::AirQuality ||
       resolved_model==M2sIkeaSensor::Motion ||
       resolved_model==M2sIkeaSensor::Contact ||
       resolved_model==M2sIkeaSensor::WaterLeak;
   // A mapped binary sensor may already have returned its state with identity.
   if(resolved_model==M2sIkeaSensor::Motion || resolved_model==M2sIkeaSensor::Contact || resolved_model==M2sIkeaSensor::WaterLeak){
       const uint32_t cluster=resolved_model==M2sIkeaSensor::Motion?0x0406:0x0045;
       for(int k=0;k<snapshot.count;k++)if(snapshot.values[k].valid && snapshot.values[k].cluster==cluster)needs_model_read=false;
   }
   if(resolved_model==M2sIkeaSensor::ThermHygro){
       bool temp=false,hum=false;
       for(int k=0;k<snapshot.count;k++)if(snapshot.values[k].valid){
           if(snapshot.values[k].cluster==0x0402)temp=true;
           if(snapshot.values[k].cluster==0x0405)hum=true;
       }
       needs_model_read=!(temp&&hum);
   }
   const int64_t now=esp_timer_get_time();
   // Preserve the NVS/UI interval (minutes), but provide a 30 s fallback for
   // default 1-minute devices that do NOT yet have a working subscription.
   // After a read error, retry with bounded backoff and no parallel CASE flood.
   if(snapshot.state==3 || snapshot.state==4){
      if(cache[i].read_failures<5)++cache[i].read_failures;
      const size_t retry_idx=static_cast<size_t>(cache[i].read_failures-1);
      cache[i].next_us=now+kRecoveryDelaysUs[retry_idx];
   }else{
      cache[i].read_failures=0;
      const int64_t configured=interval_us(cache[i].interval_minutes ? cache[i].interval_minutes : kDefaultIntervalMinutes);
      const int64_t effective=(!cache[i].sub_reporting &&
           cache[i].interval_minutes<=1) ? kFastFallbackPollUs : configured;
      cache[i].next_us=now+(needs_model_read ? kFastDispatchUs : effective);
   }
   break;
 }
}
using namespace esp_matter::controller;
// Up to two independent boot recovery requests; normal mode remains single-flight.
void finish(unsigned slot,bool success) {
    portENTER_CRITICAL(&mux);
    auto &snapshot=flights[slot].report;
    if(!snapshot.busy){portEXIT_CRITICAL(&mux);return;}
    snapshot.busy=false;
    if(snapshot.state!=4) snapshot.state=success?2:3;
    const bool battery_missing=flights[slot].battery && !snapshot.battery_valid;
    const uint32_t node=snapshot.node;
    cache_finish(snapshot);
    last_snapshot=snapshot;
    portEXIT_CRITICAL(&mux);
    ESP_LOGI("M2S_S77","READ_FINISHED node=%lu success=%u",(unsigned long)node,(unsigned)success);
    if(battery_missing)
        ESP_LOGW("M2S_BAT","BAT_NO_REPORT node=%lu retry_s=300",
                 (unsigned long)node);
}
class WebRead final : public read_command {
    const unsigned flight;
    bool complete=false;
    bool failed=false;
public:
    WebRead(unsigned slot,uint32_t node, ScopedMemoryBufferWithSize<AttributePathParams> &&paths,
            ScopedMemoryBufferWithSize<EventPathParams> &&events)
        : read_command(node,std::move(paths),std::move(events),nullptr,nullptr,nullptr),flight(slot) {}
    ~WebRead() override { if(!complete) finish(flight,false); }
    void OnAttributeData(const chip::app::ConcreteDataAttributePath &path,
                         chip::TLV::TLVReader *data, const chip::app::StatusIB &status) override {
        auto &snapshot=flights[flight].report;
        if(path.mEndpointId==0 && path.mClusterId==0x0028 &&
           (path.mAttributeId==2 || path.mAttributeId==4)){
            if(status.ToChipError()!=CHIP_NO_ERROR || !data || data->GetType()==chip::TLV::kTLVType_Null)return;
            uint16_t id=0;
            if(data->Get(id)!=CHIP_NO_ERROR)return;
            portENTER_CRITICAL(&mux);
            if(snapshot.state==1){
                if(path.mAttributeId==2){snapshot.vendor_id=id;snapshot.vendor_valid=true;}
                else {snapshot.product_id=id;snapshot.product_valid=true;}
            }
            portEXIT_CRITICAL(&mux);
            return;
        }
        if(path.mEndpointId==0 && path.mClusterId==0x002F && path.mAttributeId==0x000C){
            // Optional on some Matter nodes; failure must not invalidate T/H.
            if(status.ToChipError()!=CHIP_NO_ERROR || !data || data->GetType()==chip::TLV::kTLVType_Null)return;
            uint8_t raw=0;
            if(data->Get(raw)!=CHIP_NO_ERROR || raw>200)return;
            const int64_t now=esp_timer_get_time();
            portENTER_CRITICAL(&mux);
            if(snapshot.state==1){snapshot.battery_raw=raw;snapshot.battery_valid=true;snapshot.battery_received_us=now;}
            const uint32_t battery_node=snapshot.node;
            portEXIT_CRITICAL(&mux);
            ESP_LOGI("M2S_BAT","BAT_RX node=%lu raw=%u percent_x10=%u",
                     (unsigned long)battery_node,(unsigned)raw,(unsigned)raw*5);
            return;
        }
        if(path.mAttributeId!=0 || (path.mClusterId!=0x0402 && path.mClusterId!=0x0405 &&
           path.mClusterId!=0x0406 && path.mClusterId!=0x0045 &&
           path.mClusterId!=0x040D && path.mClusterId!=0x042A))return;
        // A wildcard cluster request normally encounters unsupported endpoints;
        // that is not a failure of the sensor or the other paths in the read.
        if(status.ToChipError()!=CHIP_NO_ERROR || !data)return;
        bool valid=data->GetType()!=chip::TLV::kTLVType_Null;
        int value=0;
        if(valid){
            if(path.mClusterId==0x0402){int16_t raw=0;if(data->Get(raw)!=CHIP_NO_ERROR)return;value=raw;valid=raw!=-32768;}
            else if(path.mClusterId==0x0405){uint16_t raw=0;if(data->Get(raw)!=CHIP_NO_ERROR)return;value=raw;valid=raw<=10000;}
            else if(path.mClusterId==0x0406){uint8_t bits=0;if(data->Get(bits)!=CHIP_NO_ERROR)return;value=(bits&1)?1:0;}
            else if(path.mClusterId==0x0045){bool state=false;if(data->Get(state)!=CHIP_NO_ERROR)return;value=state?1:0;}
            else {
                float concentration=0;
                if(data->Get(concentration)!=CHIP_NO_ERROR || !std::isfinite(concentration) ||
                   concentration<0 || concentration>1000000)return;
                value=static_cast<int>(std::lround(concentration*100.0f));
            }
        }
        const int64_t now=esp_timer_get_time();
        bool changed=true;
        portENTER_CRITICAL(&mux);
        if(snapshot.state==1){
            int64_t changed_us=now;
            if(cache)for(int k=0;k<M2S_DEVICE_LIMIT;k++)if(cache[k].node==snapshot.node){
                const auto &old=cache[k].report;
                for(int j=0;j<old.count;j++)if(old.values[j].endpoint==path.mEndpointId &&
                    old.values[j].cluster==path.mClusterId && old.values[j].valid==valid &&
                    old.values[j].value==value && old.values[j].changed_us>0){
                    changed=false;changed_us=old.values[j].changed_us;break;
                }
                break;
            }
            int i=0;
            for(;i<snapshot.count;i++)if(snapshot.values[i].endpoint==path.mEndpointId && snapshot.values[i].cluster==path.mClusterId)break;
            if(i<8){if(i==snapshot.count)snapshot.count++;snapshot.values[i]={path.mEndpointId,path.mClusterId,value,valid,now,changed_us};}
            else failed=true;
        }
        const uint32_t report_node=snapshot.node;
        portEXIT_CRITICAL(&mux);
        ESP_LOGI("M2S_READ","ATTR_RX node=%lu ep=%u cluster=0x%04lx value=%ld valid=%u changed=%u",
           (unsigned long)report_node,(unsigned)path.mEndpointId,(unsigned long)path.mClusterId,
           (long)value,(unsigned)valid,(unsigned)changed);
    }
    void OnError(CHIP_ERROR error) override { failed=true;ESP_LOGW("M2S_READ","READ_ERROR: %s",chip::ErrorStr(error));read_command::OnError(error); }
    void OnDone(chip::app::ReadClient *client) override {
        complete=true;finish(flight,!failed);
        ESP_LOGI("M2S_READ","READ_DONE success=%u",(unsigned)!failed);
        read_command::OnDone(client); // SDK owns its ReadClient; base deletes this command.
    }
};
// TIMMERFLOTTE: combined T/H subscription. Binary sensors: live Matter reports.
// MYGGBETT & KLIPPBOK = 0x0045, MYGGSPRAY = 0x0406.
// Reports update the volatile cache immediately on the CHIP event loop.
// No NVS writes, no Matter fabric or Thread dataset changes.
void subscribed_attribute(uint64_t node, const chip::app::ConcreteDataAttributePath &path,
                          chip::TLV::TLVReader *data){
    if(!data || path.mAttributeId!=0 ||
       !((path.mEndpointId==1 && path.mClusterId==0x0402) ||
         (path.mEndpointId==2 && path.mClusterId==0x0405) ||
         (path.mEndpointId>0 && (path.mClusterId==0x0045 ||
                                 path.mClusterId==0x0406))))return;
    if(data->GetType()==chip::TLV::kTLVType_Null)return;
    int raw=0;
    if(path.mClusterId==0x0045){
        bool state=false;
        if(data->Get(state)!=CHIP_NO_ERROR)return;
        raw=state?1:0; // Contact: true=closed. WaterLeak: true=leak detected.
    }else if(path.mClusterId==0x0406){
        uint8_t occupancy=0;
        if(data->Get(occupancy)!=CHIP_NO_ERROR)return;
        raw=(occupancy&1)?1:0; // Occupancy Sensing: bit0 means occupied / motion.
    }else if(path.mClusterId==0x0402){
        int16_t temp=0;
        if(data->Get(temp)!=CHIP_NO_ERROR || temp==-32768)return;
        raw=temp;
    }else{
        uint16_t humidity=0;
        if(data->Get(humidity)!=CHIP_NO_ERROR || humidity>10000)return;
        raw=humidity;
    }
    const int64_t now=esp_timer_get_time();
    bool changed=true;
    bool stored=false;
    portENTER_CRITICAL(&mux);
    if(cache)for(int i=0;i<M2S_DEVICE_LIMIT;i++)if(cache[i].node==node){
        auto &c=cache[i];
        c.sub_requested=true;
        c.sub_reporting=true;
        c.sub_retry_after_us=0;
        c.sub_report_us=now;
        ++c.sub_report_count;
        auto &r=c.report;
        r.node=static_cast<uint32_t>(node);
        r.state=2;
        int idx=0;
        for(;idx<r.count;idx++)if(r.values[idx].endpoint==path.mEndpointId &&
             r.values[idx].cluster==path.mClusterId)break;
        if(idx<8){
            int64_t changed_us=now;
            if(idx<r.count && r.values[idx].valid && r.values[idx].value==raw){
                changed=false;
                if(r.values[idx].changed_us>0)changed_us=r.values[idx].changed_us;
            }
            if(idx==r.count)++r.count;
            r.values[idx]={path.mEndpointId,path.mClusterId,raw,true,now,changed_us};
            stored=true;
        }
        break;
    }
    portEXIT_CRITICAL(&mux);
    if(stored)ESP_LOGI("M2S_SUB","SUB_REPORT node=%lu ep=%u cluster=0x%04lx value=%ld changed=%u",
       (unsigned long)node,(unsigned)path.mEndpointId,(unsigned long)path.mClusterId,(long)raw,(unsigned)changed);
    if(stored && changed && (path.mClusterId==0x0045 || path.mClusterId==0x0406))
        ESP_LOGI("M2S_BINARY","Matter live node=%lu ep=%u cluster=0x%04lx state=%ld",
                 (unsigned long)node,(unsigned)path.mEndpointId,
                 (unsigned long)path.mClusterId,(long)raw);
}
// This callback is present in ESP-Matter release/v1.5 and runs on CHIP context.
void sub_done_cb(uint64_t node, uint32_t subscription_id){
    const int64_t now=esp_timer_get_time();
    portENTER_CRITICAL(&mux);
    if(cache)for(int i=0;i<M2S_DEVICE_LIMIT;i++)if(cache[i].node==node){
        auto &c=cache[i];
        c.sub_requested=false;
        c.sub_reporting=false;
        c.sub_retry_after_us=now+kSubTerminationCooldownUs;
        break;
    }
    portEXIT_CRITICAL(&mux);
    ESP_LOGW("M2S_SUB","SUB_TERMINATED node=%lu subscription=%lu retry_after_s=30",
             (unsigned long)node,(unsigned long)subscription_id);
}
// ESP-Matter v1.5 uses a 3-argument callback. Newer ESP-Matter versions add
// StatusIB, so overload resolution selects the matching typed function pointer.
void sub_attribute_cb(uint64_t node, const chip::app::ConcreteDataAttributePath &path,
                      chip::TLV::TLVReader *data){
    subscribed_attribute(node,path,data);
}
[[maybe_unused]] void sub_attribute_cb(uint64_t node, const chip::app::ConcreteDataAttributePath &path,
                      chip::TLV::TLVReader *data, const chip::app::StatusIB &status){
    if(status.ToChipError()!=CHIP_NO_ERROR)return;
    subscribed_attribute(node,path,data);
}
void sub_work(intptr_t arg){
    const uint32_t node=static_cast<uint32_t>(arg);
    m2s_matter_status_t status{};m2s_matter_get_status(&status);
    if(readings_paused.load() || status.pair_busy || m2s_ble_scan_active() || !status.ready){
        portENTER_CRITICAL(&mux);
        if(cache)for(int i=0;i<M2S_DEVICE_LIMIT;i++)if(cache[i].node==node){
            if (!cache[i].sub_reporting) { cache[i].sub_requested = false; }
            break;
        }
        portEXIT_CRITICAL(&mux);return;
    }
    ESP_LOGI("M2S_MEM", "SUB_BEGIN node=%lu DMA=%u largest=%u",
       (unsigned long)node, (unsigned)heap_caps_get_free_size(MALLOC_CAP_DMA),
       (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_DMA));
    chip::Platform::ScopedMemoryBufferWithSize<chip::app::AttributePathParams> paths;
    chip::Platform::ScopedMemoryBufferWithSize<chip::app::EventPathParams> events;
    M2sIkeaSensor model=M2sIkeaSensor::Unknown;
    uint16_t binary_ep=1;
    portENTER_CRITICAL(&mux);
    if(cache)for(int i=0;i<M2S_DEVICE_LIMIT;i++)if(cache[i].node==node){
       const auto &r=cache[i].report;
       if(r.vendor_valid && r.product_valid)
          model=m2s_ikea_sensor(r.vendor_id,r.product_id);
       if(model==M2sIkeaSensor::Contact || model==M2sIkeaSensor::WaterLeak ||
          model==M2sIkeaSensor::Motion){
          const uint32_t cluster=(model==M2sIkeaSensor::Motion)?0x0406:0x0045;
          if(model==M2sIkeaSensor::Motion)binary_ep=2; // verified MYGGSPRAY default; report overrides
          for(int k=0;k<r.count;k++)
            if(r.values[k].cluster==cluster && r.values[k].valid){
              binary_ep=r.values[k].endpoint;break;
            }
       }
       break;
    }
    portEXIT_CRITICAL(&mux);
    const bool binary=model==M2sIkeaSensor::Contact ||
                      model==M2sIkeaSensor::Motion ||
                      model==M2sIkeaSensor::WaterLeak;
    const uint32_t binary_cluster=(model==M2sIkeaSensor::Motion)?0x0406:0x0045;
    const unsigned count=binary?1:2;
    paths.Alloc(count);
    if(!paths.Get()){
        ESP_LOGE("M2S_SUB","SUB_NOMEM node=%lu",(unsigned long)node);
        return;
    }
    if(binary){
        paths[0]=chip::app::AttributePathParams(binary_ep,binary_cluster,0);
    }else{
        paths[0]=chip::app::AttributePathParams(1,0x0402,0);
        paths[1]=chip::app::AttributePathParams(2,0x0405,0);
    }
    // Zero min interval for event-like binary sensors. Sleepy sensors may
    // still delay notifications; periodic polling remains the fallback.
    auto *cmd=chip::Platform::New<esp_matter::controller::subscribe_command>(
        node,std::move(paths),std::move(events),
        binary?0:kSubscriptionMinSeconds,kSubscriptionMaxSeconds,
        true,static_cast<esp_matter::controller::attribute_report_cb_t>(sub_attribute_cb),
        nullptr,sub_done_cb,nullptr,false);
    if(!cmd){
        ESP_LOGE("M2S_SUB","SUB_ALLOC_FAILED node=%lu",(unsigned long)node);
        return;
    }
    if(binary)
        ESP_LOGI("M2S_SUB","BINARY SUB_SEND node=%lu ep=%u cluster=0x%04lx min_s=0 max_s=%u",
                 (unsigned long)node,(unsigned)binary_ep,(unsigned long)binary_cluster,
                 (unsigned)kSubscriptionMaxSeconds);
    else
        ESP_LOGI("M2S_SUB","SUB_SEND node=%lu temp_ep=1 hum_ep=2 min_s=%u max_s=%u",
                 (unsigned long)node,(unsigned)kSubscriptionMinSeconds,(unsigned)kSubscriptionMaxSeconds);
    // SDK takes ownership and frees on connection errors/termination.
    ESP_LOGI("M2S_MEM", "SUB_PRE_SEND node=%lu DMA=%u largest=%u",
       (unsigned long)node, (unsigned)heap_caps_get_free_size(MALLOC_CAP_DMA),
       (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_DMA));
    if(cmd->send_command()!=ESP_OK){
        // SDK deletes the command on synchronous failure. Do not access cmd.
        const int64_t now=esp_timer_get_time();
        portENTER_CRITICAL(&mux);
        if(cache)for(int i=0;i<M2S_DEVICE_LIMIT;i++)if(cache[i].node==node){
            cache[i].sub_requested=false;
            cache[i].sub_reporting=false;
            cache[i].sub_retry_after_us=now+kSubTerminationCooldownUs;
            break;
        }
        portEXIT_CRITICAL(&mux);
        ESP_LOGW("M2S_SUB","SUB_SEND_FAILED node=%lu retry_after_s=30",(unsigned long)node);
    }
}
void work(intptr_t arg){
    const unsigned slot=static_cast<unsigned>(arg);
    portENTER_CRITICAL(&mux);
    const uint32_t node=flights[slot].report.node;
    const bool has_other=active_reads_locked()>1;
    portEXIT_CRITICAL(&mux);
    if(has_other && !parallel_headroom()){
        portENTER_CRITICAL(&mux);
        auto &f=flights[slot];
        if(cache)for(int i=0;i<M2S_DEVICE_LIMIT;i++)if(cache[i].node==node){
            cache[i].next_us=f.previous_due;cache[i].next_battery_us=f.previous_battery_due;break;
        }
        f.report.busy=false;
        portEXIT_CRITICAL(&mux);
        ESP_LOGW("M2S_READ","RC47D5_PARALLEL_DEFER node=%lu",(unsigned long)node);
        return;
    }
    m2s_matter_status_t status{};m2s_matter_get_status(&status);
    if(!status.ready || status.pair_busy){finish(slot,false);return;}
    ScopedMemoryBufferWithSize<AttributePathParams> paths;
    ScopedMemoryBufferWithSize<EventPathParams> events;
    portENTER_CRITICAL(&mux);
    const bool query_battery=flights[slot].battery;
    M2sIkeaSensor sensor=M2sIkeaSensor::Unknown;
    if(cache)for(int i=0;i<M2S_DEVICE_LIMIT;i++)if(cache[i].node==node &&
       cache[i].report.vendor_valid && cache[i].report.product_valid)
        sensor=m2s_ikea_sensor(cache[i].report.vendor_id,cache[i].report.product_id);
    const uint8_t hint=flights[slot].hint;
    portEXIT_CRITICAL(&mux);
    // No extra Matter tasks. Keep ReadClient path count small on 20 KiB SRAM.
    const bool identity_unknown=sensor==M2sIkeaSensor::Unknown;
    // NVS slot type is only a read-path hint; actual VID/PID is still required.
    const bool hint_motion=identity_unknown && hint==M2S_SUPLA_SENSOR_MOTION;
    const bool hint_boolean=identity_unknown && (hint==M2S_SUPLA_SENSOR_CONTACT || hint==M2S_SUPLA_SENSOR_LEAK);
    const bool hint_binary=hint_motion || hint_boolean;
    unsigned count=identity_unknown?(hint_binary?3:4):((sensor==M2sIkeaSensor::AirQuality)?4:
                     (sensor==M2sIkeaSensor::ThermHygro?2:1));
    if(query_battery)++count;
    paths.Alloc(count);
    if(!paths.Get()){finish(slot,false);return;}
    unsigned index=0;
    if(sensor==M2sIkeaSensor::ThermHygro || sensor==M2sIkeaSensor::AirQuality || (identity_unknown && !hint_binary)){
        paths[index++]=AttributePathParams(0xFFFF,0x0402,0);
        paths[index++]=AttributePathParams(0xFFFF,0x0405,0);
    }
    if(sensor==M2sIkeaSensor::Motion || hint_motion) paths[index++]=AttributePathParams(0xFFFF,0x0406,0);
    if(sensor==M2sIkeaSensor::WaterLeak || sensor==M2sIkeaSensor::Contact || hint_boolean)
        paths[index++]=AttributePathParams(0xFFFF,0x0045,0);
    if(sensor==M2sIkeaSensor::AirQuality){
        paths[index++]=AttributePathParams(0xFFFF,0x040D,0);
        paths[index++]=AttributePathParams(0xFFFF,0x042A,0);
    }
    if(identity_unknown){
        paths[index++]=AttributePathParams(0,0x0028,2);
        paths[index++]=AttributePathParams(0,0x0028,4);
    }
    if(query_battery) paths[index++]=AttributePathParams(0,0x002F,0x000C);
    if(index!=count){finish(slot,false);return;}
    auto *cmd=chip::Platform::New<WebRead>(slot,node,std::move(paths),std::move(events));
    if(!cmd){finish(slot,false);return;}
    // S7.6: distinguish a queued Matter read from a reachable operational node.
    // READ_SEND only means that the CHIP command was submitted; the mDNS/CASE
    // handshake can still fail before any attribute is read.
    ESP_LOGW("M2S_S77", "DISCOVERY_ATTEMPT node=%lu paths=%u; awaiting operational DNS-SD and CASE",
        (unsigned long)node, index);
    ESP_LOGI("M2S_READ","READ_SEND node=%lu paths=%u",(unsigned long)node,index);
    // send_command owns deletion on synchronous/asynchronous connection failure.
    cmd->send_command();
}
}
static esp_err_t request_impl(uint32_t node,bool recovery){
    if(readings_paused.load() || m2s_ble_scan_active())return ESP_ERR_INVALID_STATE;
    if(!node || node>65535)return ESP_ERR_INVALID_ARG;
    m2s_matter_status_t status{};m2s_matter_get_status(&status);
    if(!status.ready || status.pair_busy || !cache)return ESP_ERR_INVALID_STATE;
    const int64_t now=esp_timer_get_time();
    const uint16_t configured_interval=load_interval_nvs(node);
    const uint8_t hint=recovery?m2s_supla_recovery_hint(node):0;
    const bool parallel=recovery && parallel_headroom();
    unsigned slot=0,active=0;bool query_battery=false;
    portENTER_CRITICAL(&mux);
    active=active_reads_locked();
    if(readings_paused.load() || node_busy_locked(node) || active>=(parallel?2u:1u)){
       portEXIT_CRITICAL(&mux);return ESP_ERR_INVALID_STATE;
    }
    int ci=-1;
    for(int i=0;i<M2S_DEVICE_LIMIT;i++){if(cache[i].node==node){ci=i;break;}if(!cache[i].node)ci=i;}
    if(ci<0){portEXIT_CRITICAL(&mux);return ESP_ERR_NO_MEM;}
    if(cache[ci].node!=node){cache[ci]={};cache[ci].node=node;}
    auto &c=cache[ci];c.interval_minutes=configured_interval;
    const int64_t previous_due=c.next_us,previous_battery_due=c.next_battery_us;
    c.next_us=now+interval_us(configured_interval);
    const bool initial_mapped=recovery && hint && (!c.report.vendor_valid || !c.report.product_valid);
    query_battery=!initial_mapped && now>=c.next_battery_us;
    if(query_battery)c.next_battery_us=now+kBatteryRetryUs;
    slot=flights[0].report.busy?1:0;
    auto &f=flights[slot];f={};f.battery=query_battery;f.hint=hint;f.previous_due=previous_due;f.previous_battery_due=previous_battery_due;
    f.report.node=node;f.report.busy=true;f.report.state=1;f.report.started_us=now;
    portEXIT_CRITICAL(&mux);
    if(query_battery)ESP_LOGI("M2S_BAT","BAT_QUERY node=%lu",(unsigned long)node);
    ESP_LOGI("M2S_READ","RC47D5_READ_SLOT node=%lu slot=%u active=%u hint=%u battery=%u",(unsigned long)node,slot,active+1,(unsigned)hint,(unsigned)query_battery);
    ESP_LOGI("M2S_READ","READ_QUEUED node=%lu interval_min=%u",(unsigned long)node,(unsigned)configured_interval);
    if(chip::DeviceLayer::PlatformMgr().ScheduleWork(work,static_cast<intptr_t>(slot))!=CHIP_NO_ERROR){finish(slot,false);return ESP_FAIL;}
    return ESP_OK;
}
esp_err_t m2s_readings_request(uint32_t node){return request_impl(node,false);}
void m2s_readings_snapshot(m2s_readings_t *out){
    const int64_t now=esp_timer_get_time();
    portENTER_CRITICAL(&mux);
    *out=last_snapshot;
    for(auto &f:flights)if(f.report.busy){
       if(f.report.state==1 && now-f.report.started_us>=90000000LL)f.report.state=4;
       if(!out->busy)*out=f.report;
    }
    portEXIT_CRITICAL(&mux);
}

extern "C" void m2s_readings_init(void){
 cache=static_cast<Cached*>(heap_caps_calloc(M2S_DEVICE_LIMIT,sizeof(Cached),MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT));
 if(!cache)ESP_LOGE("M2S_READ", "Background cache allocation failed");
 set_next_dispatch(esp_timer_get_time()+kInitialDispatchUs); // first pass ASAP once Thread/Matter are ready
}
bool m2s_readings_cached(uint32_t node,m2s_readings_t *out){
 bool found=false;
 portENTER_CRITICAL(&mux);
 if(cache)for(int i=0;i<M2S_DEVICE_LIMIT;i++)if(cache[i].node==node){*out=cache[i].report;out->node=node;found=true;break;}
 for(const auto &f:flights)if(f.report.node==node && f.report.busy){out->node=node;out->busy=true;out->state=f.report.state;out->started_us=f.report.started_us;found=true;break;}
 portEXIT_CRITICAL(&mux);
 return found;
}
void m2s_readings_tick(){
 if(readings_paused.load() || m2s_ble_scan_active())return; // defer new polls/subs while BLE scans
 const int64_t now=esp_timer_get_time();
 if(!cache || now<get_next_dispatch())return;
 m2s_readings_t active{};m2s_readings_snapshot(&active);
 unsigned in_flight=0;portENTER_CRITICAL(&mux);in_flight=active_reads_locked();portEXIT_CRITICAL(&mux);
 if(in_flight>=2)return;
 m2s_network_status_t net{};m2s_network_status(&net);
 m2s_matter_status_t ms{};m2s_matter_get_status(&ms);
 if(!net.connected||net.ap_active||net.testing||!ms.ready||ms.pair_busy)return;
 // RC47D3: boot-only recovery guard, no changes to normal retry intervals.
 static int64_t recovery_start=0;
 static bool recovery_gate_done=false;
 static int64_t next_recovery_probe=0;
 static int64_t next_recovery_log=0;
 if(!recovery_gate_done && now<next_recovery_probe)return;
 bool attached=false;
 unsigned children=0,restoring=0;
 uint32_t advertised[M2S_DEVICE_LIMIT]{};size_t advertised_count=0;
 const bool scan_srp=!recovery_start || now-recovery_start<300000000LL;
 if(esp_openthread_lock_acquire(pdMS_TO_TICKS(20))){
   auto *instance=esp_openthread_get_instance();
   if(instance){
     auto role=otThreadGetDeviceRole(instance);
     attached=role==OT_DEVICE_ROLE_LEADER||role==OT_DEVICE_ROLE_ROUTER||role==OT_DEVICE_ROLE_CHILD;
     // Read-only SRP hints; never treat advertisements as authenticated readings.
     if(attached && scan_srp){
       for(const otSrpServerHost *host=nullptr;(host=otSrpServerGetNextHost(instance,host))!=nullptr && advertised_count<M2S_DEVICE_LIMIT;){
         if(otSrpServerHostIsDeleted(host))continue;
         for(const otSrpServerService *svc=nullptr;(svc=otSrpServerHostGetNextService(host,svc))!=nullptr && advertised_count<M2S_DEVICE_LIMIT;){
           if(otSrpServerServiceIsDeleted(svc))continue;
           const char *name=otSrpServerServiceGetInstanceName(svc);
           if(!name || std::strlen(name)<46 || name[16]!='-' || std::strncmp(name+33,"._matter._tcp",13)!=0 || (name[46]!=0 && name[46]!='.'))continue;
           uint64_t id=0;bool valid=true;
           for(unsigned k=0;k<33;k++){
             if(k==16)continue;
             const char ch=name[k];unsigned x;
             if(ch>='0' && ch<='9')x=ch-'0';else if(ch>='a'&&ch<='f')x=ch-'a'+10;else if(ch>='A'&&ch<='F')x=ch-'A'+10;else {valid=false;break;}
             if(k>16)id=(id<<4)|x;
           }
           if(!valid || !id || id>65535)continue;
           bool duplicate=false;for(size_t i=0;i<advertised_count;i++)if(advertised[i]==id)duplicate=true;
           if(!duplicate)advertised[advertised_count++]=static_cast<uint32_t>(id);
         }
       }
     }
     if(attached && !recovery_gate_done && (role==OT_DEVICE_ROLE_LEADER||role==OT_DEVICE_ROLE_ROUTER)){
       for(uint16_t idx=0;idx<32;++idx){
         otChildInfo child{};
         if(otThreadGetChildInfoByIndex(instance,idx,&child)==OT_ERROR_NONE){
           ++children;if(child.mIsStateRestoring)++restoring;
         }
       }
     }
   }
   esp_openthread_lock_release();
 }
 if(!attached)return;
 if(!recovery_start)recovery_start=now;
 const bool recovery_priority=now-recovery_start<300000000LL;
 if(in_flight && (!recovery_priority || !parallel_headroom()))return;
 if(!recovery_gate_done){
   if(children && children==restoring && now-recovery_start<10000000LL){
     next_recovery_probe=now+500000LL;
     if(now>=next_recovery_log){
       next_recovery_log=now+10000000LL;
       ESP_LOGI("M2S_READ","RC47D3_RESTORE_WAIT children=%u restoring=%u",children,restoring);
     }
     return;
   }
   // Let the first SRP registrations arrive, but never block for more than 3s here.
   if(children && !advertised_count && now-recovery_start<3000000LL){next_recovery_probe=now+250000LL;return;}
   recovery_gate_done=true;
   ESP_LOGI("M2S_READ","RC47D3_RESTORE_READY children=%u restoring=%u elapsed_s=%lld",children,restoring,(long long)((now-recovery_start)/1000000LL));
 }
 m2s_device_t devices[M2S_DEVICE_LIMIT]{};const size_t count=m2s_devices_snapshot(devices,M2S_DEVICE_LIMIT);
 portENTER_CRITICAL(&mux);
 for(int i=0;i<M2S_DEVICE_LIMIT;i++)if(cache[i].node){bool present=false;for(size_t j=0;j<count;j++)if(devices[j].node==cache[i].node)present=true;if(!present)cache[i]={};}
 portEXIT_CRITICAL(&mux);
 const int64_t dispatch_gap=recovery_priority && parallel_headroom()?kStartupDispatchUs:kFastDispatchUs;
 // Do not initiate a new subscription while a ReadClient is active. Existing
 // subscriptions may still report; their callbacks preserve per-node caches.
 // During the boot pass, prefer read requests for unmeasured advertised nodes.
 bool unseen_ready=false;
 if(recovery_priority){
   portENTER_CRITICAL(&mux);
   for(size_t j=0;j<count;j++){
     const auto &d=devices[j];if(d.state!=0 && d.state!=2)continue;
     if(node_busy_locked(d.node))continue;
     bool advertised_node=false;for(size_t a=0;a<advertised_count;a++)if(advertised[a]==d.node)advertised_node=true;
     if(!advertised_node)continue;
     int64_t due=0;bool measured=false;uint8_t failures=0;
     for(int i=0;i<M2S_DEVICE_LIMIT;i++)if(cache[i].node==d.node){
       due=cache[i].next_us;failures=cache[i].read_failures;
       for(int k=0;k<cache[i].report.count;k++)if(cache[i].report.values[k].valid && cache[i].report.values[k].received_us>0)measured=true;
       break;
     }
     if(!measured && !failures && now>=due){unseen_ready=true;break;}
   }
   portEXIT_CRITICAL(&mux);
 }
 if(!in_flight && !unseen_ready)for(size_t j=0;j<count;j++){
   const auto &d=devices[j];
   if(d.state!=0 && d.state!=2)continue;
   bool start_sub=false;
   portENTER_CRITICAL(&mux);
   for(int i=0;i<M2S_DEVICE_LIMIT;i++)if(cache[i].node==d.node){
       auto &c=cache[i];
       const auto model=(c.report.vendor_valid && c.report.product_valid)?
           m2s_ikea_sensor(c.report.vendor_id,c.report.product_id):M2sIkeaSensor::Unknown;
       const bool can_subscribe=model==M2sIkeaSensor::ThermHygro ||
           model==M2sIkeaSensor::Contact || model==M2sIkeaSensor::Motion ||
           model==M2sIkeaSensor::WaterLeak;
       const int64_t establish_retry=(model==M2sIkeaSensor::Motion)?
           kMotionEstablishRetryUs:kSubscriptionRetryUs;
       // An unfinished Motion subscription must not block live motion for 15 min.
       // Established subscriptions retry only after 15 min without any reports;
       // normal occupancy=1 can remain active due to the sensor's own HoldTime.
       const bool retry_due=!c.sub_requested ||
           (!c.sub_reporting && now-c.sub_requested_us>=establish_retry) ||
           (c.sub_reporting && now-c.sub_report_us>=kSubscriptionRetryUs &&
            now-c.sub_requested_us>=kSubscriptionRetryUs);
       if(!readings_paused.load() && can_subscribe && now>=c.sub_retry_after_us && retry_due){
           // RC2: do not duplicate a subscription that is already reporting.
           if (!c.sub_reporting) {
               c.sub_requested=true;
               c.sub_reporting=false;
               c.sub_requested_us=now;
               start_sub=true;
           }
       }
       break;
   }
   portEXIT_CRITICAL(&mux);
   if(start_sub){
       ESP_LOGI("M2S_MEM", "SUB_SCHEDULE node=%lu DMA=%u largest=%u",
           (unsigned long)d.node,
           (unsigned)heap_caps_get_free_size(MALLOC_CAP_DMA),
           (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_DMA));
       if(chip::DeviceLayer::PlatformMgr().ScheduleWork(sub_work,static_cast<intptr_t>(d.node))!=CHIP_NO_ERROR){
           portENTER_CRITICAL(&mux);
           for(int i=0;i<M2S_DEVICE_LIMIT;i++)if(cache[i].node==d.node)cache[i].sub_requested=false;
           portEXIT_CRITICAL(&mux);
           ESP_LOGW("M2S_SUB","SUB_QUEUE_FAILED node=%lu",(unsigned long)d.node);
       }
       set_next_dispatch(now+kFastDispatchUs);
       return; // Avoid starting a poll during subscription setup.
   }
 }
 // Prioritize boot-time first measurements, especially SRP-advertised nodes.
 // The SRP label is only a scheduling hint, not proof of identity or liveness.
 // Keep the existing per-node retry due time and the usual round robin after boot.
 size_t preferred=count;
 if(recovery_priority){
   int best=-1;
   portENTER_CRITICAL(&mux);
   for(size_t j=0;j<count;j++){
     const size_t index=(cursor+j)%count;const auto &d=devices[index];
     if(d.state!=0&&d.state!=2)continue;
     if(node_busy_locked(d.node))continue;
     int64_t due=0;uint8_t failures=0;bool measured=false;
     for(int i=0;i<M2S_DEVICE_LIMIT;i++)if(cache[i].node==d.node){
       due=cache[i].next_us;failures=cache[i].read_failures;
       for(int k=0;k<cache[i].report.count;k++)if(cache[i].report.values[k].valid && cache[i].report.values[k].received_us>0)measured=true;
       break;
     }
     if(now<due)continue;
     bool seen=false;for(size_t a=0;a<advertised_count;a++)if(advertised[a]==d.node)seen=true;
     const int rank=measured?1:(failures?(seen?3:2):(seen?5:4));
     if(rank>best){best=rank;preferred=index;}
   }
   portEXIT_CRITICAL(&mux);
 }
 for(size_t j=0;j<count;j++){
   const size_t index=(cursor+j)%count;const auto &d=devices[index];if(d.state!=0&&d.state!=2)continue;
   if(preferred<count && index!=preferred)continue;
   int64_t due=0;portENTER_CRITICAL(&mux);const bool busy=node_busy_locked(d.node);for(int i=0;i<M2S_DEVICE_LIMIT;i++)if(cache[i].node==d.node)due=cache[i].next_us;portEXIT_CRITICAL(&mux);
   if(busy || now<due)continue;
   if(recovery_priority)ESP_LOGI("M2S_READ","RC47D5_RECOVERY_PICK node=%lu advertised=%u in_flight=%u",(unsigned long)d.node,(unsigned)advertised_count,in_flight);
   cursor=(index+1)%count;
   set_next_dispatch(now+dispatch_gap);
   ESP_LOGI("M2S_S77","FAST_DISPATCH node=%lu due_ms_ago=%lld stagger_ms=%lld",(unsigned long)d.node,(long long)((now-due)/1000),(long long)(dispatch_gap/1000));
   ESP_LOGI("M2S_READ","POLL_DUE node=%lu due_ms_ago=%lld",(unsigned long)d.node,(long long)((now-due)/1000));
   const esp_err_t result=request_impl(d.node,recovery_priority);
   if(result!=ESP_OK)ESP_LOGW("M2S_READ","POLL_REQUEST_FAILED node=%lu err=%ld",(unsigned long)d.node,(long)result);
   return;
 }
}

extern "C" bool m2s_readings_is_paused(void){return readings_paused.load();}
extern "C" void m2s_readings_set_paused(bool paused){
 readings_paused.store(paused);
 ESP_LOGW("M2S_S79","READINGS_%s: existing in-flight read will finish; established subscription reports may continue",paused?"PAUSED":"RESUMED");
}
extern "C" esp_err_t m2s_readings_run_all(void){
 if(!cache)return ESP_ERR_INVALID_STATE;
 m2s_device_t devices[M2S_DEVICE_LIMIT]{};
 const size_t count=m2s_devices_snapshot(devices,M2S_DEVICE_LIMIT);
 const int64_t now=esp_timer_get_time();
 portENTER_CRITICAL(&mux);
 for(size_t j=0;j<count;j++)if(devices[j].state==0 || devices[j].state==2){
   bool found=false;
   for(int i=0;i<M2S_DEVICE_LIMIT;i++)if(cache[i].node==devices[j].node){cache[i].next_us=now;found=true;break;}
   if(!found)for(int i=0;i<M2S_DEVICE_LIMIT;i++)if(!cache[i].node){cache[i]={};cache[i].node=devices[j].node;cache[i].interval_minutes=kDefaultIntervalMinutes;cache[i].next_us=now;break;}
 }
 next_dispatch=now;
 portEXIT_CRITICAL(&mux);
 readings_paused.store(false);
 ESP_LOGW("M2S_S79","READINGS_RUN_ALL queued=%u, bounded Matter reads",(unsigned)count);
 return ESP_OK;
}
uint16_t m2s_readings_interval_minutes(uint32_t node){
 if(node<1 || node>65535)return kDefaultIntervalMinutes;
 uint16_t result=0;
 portENTER_CRITICAL(&mux);
 if(cache)for(int i=0;i<M2S_DEVICE_LIMIT;i++){
   if(cache[i].node==node){result=cache[i].interval_minutes;break;}
 }
 portEXIT_CRITICAL(&mux);
 return result?result:load_interval_nvs(node);
}
esp_err_t m2s_readings_set_interval(uint32_t node,uint16_t minutes){
 if(node<1 || node>65535 || minutes<kMinIntervalMinutes || minutes>kMaxIntervalMinutes)
   return ESP_ERR_INVALID_ARG;
 if(!cache)return ESP_ERR_INVALID_STATE;
 // Only a locally registered node may receive an interval override.
 m2s_device_t devices[M2S_DEVICE_LIMIT]{};
 const size_t count=m2s_devices_snapshot(devices,M2S_DEVICE_LIMIT);
 bool registered=false;
 for(size_t i=0;i<count;i++)if(devices[i].node==node && (devices[i].state==0 || devices[i].state==2)){
   registered=true;break;
 }
 if(!registered)return ESP_ERR_NOT_FOUND;
 nvs_handle_t nvs=0;
 esp_err_t err=nvs_open(kPollNamespace,NVS_READWRITE,&nvs);
 if(err!=ESP_OK)return err;
 char key[12]{};poll_key(node,key);
 err=nvs_set_u16(nvs,key,minutes);
 if(err==ESP_OK)err=nvs_commit(nvs);
 nvs_close(nvs);
 if(err!=ESP_OK)return err;
 // Do not start a read immediately; apply a new due time without reboot.
 const int64_t next=esp_timer_get_time()+interval_us(minutes);
 portENTER_CRITICAL(&mux);
 for(int i=0;i<M2S_DEVICE_LIMIT;i++)if(cache[i].node==node){
   cache[i].interval_minutes=minutes;
   cache[i].next_us=next;
   break;
 }
 portEXIT_CRITICAL(&mux);
 ESP_LOGI("M2S_READ","Poll interval for node %lu: %u min",(unsigned long)node,(unsigned)minutes);
 return ESP_OK;
}

bool m2s_readings_subscription(uint32_t node,m2s_subscription_t *out){
 if(!out)return false;
 *out={};
 bool found=false;
 portENTER_CRITICAL(&mux);
 if(cache)for(int i=0;i<M2S_DEVICE_LIMIT;i++)if(cache[i].node==node){
   const auto &c=cache[i];
   out->requested=c.sub_requested;out->reporting=c.sub_reporting;
   out->requested_us=c.sub_requested_us;out->report_us=c.sub_report_us;
   out->report_count=c.sub_report_count;found=true;break;
 }
 portEXIT_CRITICAL(&mux);
 return found;
}
