#pragma once
#include <stdint.h>
#include <stddef.h>
#ifdef __cplusplus
extern "C" {
#endif

// Last boot reason is kept in RAM for the HTTP API.
// RTC_NOINIT marker identifies explicitly planned software resets when retained.
void m2s_diag_boot(void);
void m2s_diag_mark_planned_restart(unsigned kind);
const char *m2s_diag_reset_reason(void);
const char *m2s_diag_planned_reason(void);
int m2s_diag_reset_code(void);
int m2s_diag_was_planned(void);

// Zero-allocation heap failure counters; safe to read from HTTP.
uint32_t m2s_diag_alloc_fail_count(void);
size_t m2s_diag_alloc_fail_last_size(void);
uint32_t m2s_diag_alloc_fail_last_caps(void);

enum {
    M2S_DIAG_RESTART_SUPLA = 1,
    M2S_DIAG_RESTART_FACTORY = 2
};
#ifdef __cplusplus
}
#endif
