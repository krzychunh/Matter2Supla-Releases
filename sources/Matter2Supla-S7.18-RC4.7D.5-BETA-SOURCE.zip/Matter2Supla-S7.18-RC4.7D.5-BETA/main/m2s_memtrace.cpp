// Matter2Supla S7.17 RC3.3 - low-overhead failed-allocation trace + worker telemetry.
// This module DOES NOT register a new allocation callback. The patcher
// attaches m2s_memtrace_record() to the already registered existing hook.
#include "m2s_memtrace.h"
#include "esp_heap_caps.h"
#include "esp_timer.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <atomic>
#include <stdint.h>
#include <string.h>

namespace {
constexpr unsigned kCapacity = 16;
constexpr int64_t kLogSpacingUs = 1500000LL;
constexpr int64_t kSummarySpacingUs = 60000000LL;
constexpr uint32_t kRequiredCaps = MALLOC_CAP_INTERNAL | MALLOC_CAP_DMA | MALLOC_CAP_8BIT;
struct Failure {
    uint32_t sequence;
    uint32_t size;
    uint32_t caps;
    int64_t time_us;
    const char *api;
    char task_name[16];
    uint8_t isr;
    int64_t pre_probe_us;
    uint32_t pre_caps_free_bytes;
    uint32_t pre_caps_largest_bytes;
};

struct Probe {
    int64_t time_us;
    uint32_t caps_free_bytes;
    uint32_t caps_largest_bytes;
};
Probe last_probe{}; // Protected by gate; sampled by worker outside allocator hook.
Failure ring[kCapacity]{};
uint32_t written_sequence = 0;
uint32_t consumed_sequence = 0;
// A try-lock is intentionally non-blocking, including in interrupt context.
std::atomic_flag gate = ATOMIC_FLAG_INIT;
std::atomic<uint32_t> dropped_due_to_contention{0};
std::atomic<uint32_t> tick_invocations{0}; // M2S-S717-RC31-MEMTRACE-HTTP
// Updated only while gate is held. Never queried from the heap-failure callback.
uint32_t failures_wifi = 0;
uint32_t failures_lwip = 0;
uint32_t failures_httpd = 0;
uint32_t failures_other = 0;
}

extern "C" void m2s_memtrace_record(size_t size, uint32_t caps, const char *api)
{
    if (gate.test_and_set(std::memory_order_acquire)) {
        dropped_due_to_contention.fetch_add(1, std::memory_order_relaxed);
        return;
    }
    const uint32_t sequence = ++written_sequence;
    Failure &slot = ring[(sequence - 1u) % kCapacity];
    slot.sequence = sequence;
    slot.size = static_cast<uint32_t>(size);
    slot.caps = caps;
    slot.time_us = esp_timer_get_time();
    slot.api = api; // ESP-IDF passes a pointer to a persistent function name.
    // M2S-S717-RC32-ALLOC-CONTEXT - no heap queries, malloc, logging or blocking in this callback.
    const bool in_isr = xPortInIsrContext() != pdFALSE;
    slot.isr = in_isr ? 1u : 0u;
    const char *name = in_isr ? "ISR" : "unknown";
    if (!in_isr) {
        const char *candidate = pcTaskGetName(nullptr);
        if (candidate) name = candidate;
    }
    unsigned n = 0;
    while (n + 1 < sizeof(slot.task_name) && name[n]) {
        slot.task_name[n] = name[n];
        ++n;
    }
    slot.task_name[n] = '\0';
    // Fixed-cost counters; no allocations, logging, or heap inspection in the hook.
    if (strcmp(slot.task_name, "wifi") == 0) ++failures_wifi;
    else if (strcmp(slot.task_name, "tiT") == 0 || strcmp(slot.task_name, "tcpip") == 0) ++failures_lwip;
    else if (strcmp(slot.task_name, "httpd") == 0) ++failures_httpd;
    else ++failures_other;
    slot.pre_probe_us = last_probe.time_us;
    slot.pre_caps_free_bytes = last_probe.caps_free_bytes;
    slot.pre_caps_largest_bytes = last_probe.caps_largest_bytes;
    gate.clear(std::memory_order_release);
}

extern "C" void m2s_memtrace_tick(void)
{
    tick_invocations.fetch_add(1, std::memory_order_relaxed);
    static bool announced = false;
    static int64_t next_log_us = 0;
    static int64_t next_summary_us = 0;
    static uint32_t sampled_low_free = UINT32_MAX;
    static uint32_t sampled_low_largest = UINT32_MAX;
    static uint32_t sampled_count = 0;
    if (!announced) {
        announced = true;
        ESP_LOGI("M2S_MEMTRACE", "RC3.3 telemetry active; existing alloc-fail callback preserved; ring=16");
    }
    const int64_t now_us = esp_timer_get_time();
    // M2S-S717-RC32-ALLOC-CONTEXT - periodic heap probe in worker context, NEVER inside alloc-fail callback.
    static int64_t next_probe_us = 0;
    if (now_us >= next_probe_us) {
        const uint32_t free_bytes = static_cast<uint32_t>(heap_caps_get_free_size(kRequiredCaps));
        const uint32_t largest_bytes = static_cast<uint32_t>(heap_caps_get_largest_free_block(kRequiredCaps));
        if (free_bytes < sampled_low_free) sampled_low_free = free_bytes;
        if (largest_bytes < sampled_low_largest) sampled_low_largest = largest_bytes;
        ++sampled_count;
        // No heap query is done with gate held; no spinning or blocking on allocator hook.
        if (!gate.test_and_set(std::memory_order_acquire)) {
            last_probe.time_us = now_us;
            last_probe.caps_free_bytes = free_bytes;
            last_probe.caps_largest_bytes = largest_bytes;
            gate.clear(std::memory_order_release);
        }
        next_probe_us = now_us + 500000LL; // unchanged: worker samples every 500 ms
    }
    // Every 60 seconds, capture heap structure and per-task counts in worker context.
    // No heap APIs are called under gate or inside the alloc-failure callback.
    if (now_us >= next_summary_us) {
        next_summary_us = now_us + kSummarySpacingUs;
        multi_heap_info_t info{};
        heap_caps_get_info(&info, kRequiredCaps);
        uint32_t count = 0, wifi = 0, lwip = 0, httpd = 0, other = 0, lost = 0;
        bool counters_ok = false;
        if (!gate.test_and_set(std::memory_order_acquire)) {
            count = written_sequence;
            wifi = failures_wifi;
            lwip = failures_lwip;
            httpd = failures_httpd;
            other = failures_other;
            gate.clear(std::memory_order_release);
            counters_ok = true;
        }
        lost = dropped_due_to_contention.load(std::memory_order_relaxed);
        ESP_LOGI("M2S_MEMTRACE",
                 "RC33_SUMMARY uptime_s=%lld counters_ok=%u fails=%lu wifi=%lu lwip=%lu httpd=%lu other=%lu contention=%lu "
                 "free=%lu largest=%lu lifetime_min=%lu probe_min_free=%lu probe_min_largest=%lu "
                 "free_blocks=%lu allocated_blocks=%lu samples=%lu",
                 static_cast<long long>(now_us / 1000000LL),
                 static_cast<unsigned>(counters_ok),
                 static_cast<unsigned long>(count),
                 static_cast<unsigned long>(wifi),
                 static_cast<unsigned long>(lwip),
                 static_cast<unsigned long>(httpd),
                 static_cast<unsigned long>(other),
                 static_cast<unsigned long>(lost),
                 static_cast<unsigned long>(info.total_free_bytes),
                 static_cast<unsigned long>(info.largest_free_block),
                 static_cast<unsigned long>(info.minimum_free_bytes),
                 static_cast<unsigned long>(sampled_low_free == UINT32_MAX ? 0 : sampled_low_free),
                 static_cast<unsigned long>(sampled_low_largest == UINT32_MAX ? 0 : sampled_low_largest),
                 static_cast<unsigned long>(info.free_blocks),
                 static_cast<unsigned long>(info.allocated_blocks),
                 static_cast<unsigned long>(sampled_count));
    }
    if (now_us < next_log_us) return;
    // We never wait on a hook that may run inside an allocator.
    if (gate.test_and_set(std::memory_order_acquire)) return;
    Failure e{};
    uint32_t overwritten = 0;
    bool have = false;
    if (written_sequence != consumed_sequence) {
        const uint32_t pending = written_sequence - consumed_sequence;
        if (pending > kCapacity) {
            overwritten = pending - kCapacity;
            consumed_sequence = written_sequence - kCapacity;
        }
        ++consumed_sequence;
        e = ring[(consumed_sequence - 1u) % kCapacity];
        have = (e.sequence == consumed_sequence);
    }
    gate.clear(std::memory_order_release);
    if (!have) return;
    next_log_us = now_us + kLogSpacingUs;

    // Post-event measurements, deliberately outside the hook.
    // Values here are NOT the heap state at the exact instant of failure.
    const size_t dma_free = heap_caps_get_free_size(MALLOC_CAP_DMA);
    const size_t dma_largest = heap_caps_get_largest_free_block(MALLOC_CAP_DMA);
    const size_t internal_free = heap_caps_get_free_size(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    const size_t internal_largest = heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    ESP_LOGW("M2S_MEMTRACE",
             "FAIL seq=%lu size=%lu caps=0x%08lx api=%s task=%s isr=%u event_us=%lld "
             "lag_ms=%lld pre_age_ms=%lld pre_free=%lu pre_largest=%lu post_dma=%lu post_dma_largest=%lu "
             "post_internal=%lu post_internal_largest=%lu "
             "lost_overwrite=%lu lost_contention_total=%lu",
             static_cast<unsigned long>(e.sequence),
             static_cast<unsigned long>(e.size),
             static_cast<unsigned long>(e.caps),
             e.api ? e.api : "?",
             e.task_name,
             static_cast<unsigned>(e.isr),
             static_cast<long long>(e.time_us),
             static_cast<long long>((now_us - e.time_us) / 1000),
             static_cast<long long>(e.pre_probe_us ? (e.time_us - e.pre_probe_us) / 1000 : -1),
             static_cast<unsigned long>(e.pre_caps_free_bytes),
             static_cast<unsigned long>(e.pre_caps_largest_bytes),
             static_cast<unsigned long>(dma_free),
             static_cast<unsigned long>(dma_largest),
             static_cast<unsigned long>(internal_free),
             static_cast<unsigned long>(internal_largest),
             static_cast<unsigned long>(overwritten),
             static_cast<unsigned long>(dropped_due_to_contention.load(std::memory_order_relaxed)));
}

// M2S-S717-RC31-MEMTRACE-HTTP: heap-free non-destructive ring snapshot.
extern "C" bool m2s_memtrace_snapshot(m2s_memtrace_snapshot_t *out)
{
    if (!out) return false;
    if (gate.test_and_set(std::memory_order_acquire)) return false;
    out->recorded_total = written_sequence;
    out->drained_total = consumed_sequence;
    out->contention_drops = dropped_due_to_contention.load(std::memory_order_relaxed);
    out->tick_calls = tick_invocations.load(std::memory_order_relaxed);
    const uint32_t count = (written_sequence > kCapacity) ? kCapacity : written_sequence;
    const uint32_t first = written_sequence - count + 1u;
    out->event_count = 0;
    for (uint32_t i = 0; i < count; ++i) {
        const uint32_t sequence = first + i;
        const Failure &e = ring[(sequence - 1u) % kCapacity];
        if (e.sequence != sequence) continue;
        m2s_memtrace_event_t &d = out->events[out->event_count++];
        d.seq = e.sequence;
        d.size = e.size;
        d.caps = e.caps;
        d.event_us = e.time_us;
        d.api = e.api;
        for (unsigned j=0; j<sizeof(d.task_name); ++j) d.task_name[j]=e.task_name[j];
        d.isr = e.isr;
        d.pre_probe_us = e.pre_probe_us;
        d.pre_caps_free_bytes = e.pre_caps_free_bytes;
        d.pre_caps_largest_bytes = e.pre_caps_largest_bytes;
    }
    gate.clear(std::memory_order_release);
    return true;
}
