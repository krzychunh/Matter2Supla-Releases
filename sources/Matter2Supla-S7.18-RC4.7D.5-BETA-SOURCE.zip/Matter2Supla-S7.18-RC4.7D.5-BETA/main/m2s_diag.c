#include "m2s_memtrace.h"
#include "m2s_diag.h"
#include <stdint.h>
#include <stdbool.h>
#include "esp_attr.h"
#include "esp_log.h"
#include "esp_heap_caps.h"
#include "esp_system.h"

// RTC non-init memory is not written to Flash. Power-on clears trust in marker.
#define M2S_DIAG_MAGIC 0x53373137U
#define M2S_DIAG_MAGIC_INV (~M2S_DIAG_MAGIC)
RTC_NOINIT_ATTR static uint32_t s_magic;
RTC_NOINIT_ATTR static uint32_t s_magic_inv;
RTC_NOINIT_ATTR static uint32_t s_planned_kind;
RTC_NOINIT_ATTR static uint32_t s_planned_kind_inv;

static esp_reset_reason_t s_reason = ESP_RST_UNKNOWN;
static unsigned s_last_planned_kind;
static bool s_was_planned;

// The allocator invokes this in the allocating task context. Do NOT log, malloc
// or take a lock inside this callback (it would risk recursive allocation).
static uint32_t s_alloc_fail_count;
static size_t s_alloc_fail_size;
static uint32_t s_alloc_fail_caps;
static void alloc_failure_hook(size_t size, uint32_t caps, const char *function_name)
{
    // M2S-S717-RC3-MEMTRACE: preserve existing alloc-fail callback
    m2s_memtrace_record(size, caps, function_name);
    (void)function_name;
    __atomic_fetch_add(&s_alloc_fail_count, 1u, __ATOMIC_RELAXED);
    __atomic_store_n(&s_alloc_fail_size, size, __ATOMIC_RELAXED);
    __atomic_store_n(&s_alloc_fail_caps, caps, __ATOMIC_RELAXED);
}
uint32_t m2s_diag_alloc_fail_count(void) { return __atomic_load_n(&s_alloc_fail_count, __ATOMIC_RELAXED); }
size_t m2s_diag_alloc_fail_last_size(void) { return __atomic_load_n(&s_alloc_fail_size, __ATOMIC_RELAXED); }
uint32_t m2s_diag_alloc_fail_last_caps(void) { return __atomic_load_n(&s_alloc_fail_caps, __ATOMIC_RELAXED); }


static const char *reason_name(esp_reset_reason_t reason)
{
    switch (reason) {
    case ESP_RST_POWERON: return "POWERON";
    case ESP_RST_EXT: return "EXT";
    case ESP_RST_SW: return "SW";
    case ESP_RST_PANIC: return "PANIC";
    case ESP_RST_INT_WDT: return "INT_WDT";
    case ESP_RST_TASK_WDT: return "TASK_WDT";
    case ESP_RST_WDT: return "WDT";
    case ESP_RST_DEEPSLEEP: return "DEEPSLEEP";
    case ESP_RST_BROWNOUT: return "BROWNOUT";
    case ESP_RST_SDIO: return "SDIO";
    case ESP_RST_USB: return "USB";
    case ESP_RST_JTAG: return "JTAG";
    case ESP_RST_EFUSE: return "EFUSE";
    case ESP_RST_PWR_GLITCH: return "PWR_GLITCH";
    case ESP_RST_CPU_LOCKUP: return "CPU_LOCKUP";
    default: return "UNKNOWN";
    }
}

const char *m2s_diag_reset_reason(void) { return reason_name(s_reason); }
int m2s_diag_reset_code(void) { return (int)s_reason; }
int m2s_diag_was_planned(void) { return s_was_planned ? 1 : 0; }

const char *m2s_diag_planned_reason(void)
{
    if (!s_was_planned) return "none";
    switch (s_last_planned_kind) {
    case M2S_DIAG_RESTART_SUPLA: return "supla_config";
    case M2S_DIAG_RESTART_FACTORY: return "factory_reset";
    default: return "unclassified";
    }
}

void m2s_diag_mark_planned_restart(unsigned kind)
{
    // Call directly before esp_restart(), never when scheduling a timer.
    s_planned_kind = (uint32_t)kind;
    s_planned_kind_inv = ~s_planned_kind;
    s_magic_inv = M2S_DIAG_MAGIC_INV;
    s_magic = M2S_DIAG_MAGIC;
}

void m2s_diag_boot(void)
{
    s_reason = esp_reset_reason();
    if (heap_caps_register_failed_alloc_callback(alloc_failure_hook) != ESP_OK)
        ESP_LOGW("M2S_MEM", "Failed to register allocation hook");
    s_was_planned = (s_reason == ESP_RST_SW &&
                     s_magic == M2S_DIAG_MAGIC &&
                     s_magic_inv == M2S_DIAG_MAGIC_INV &&
                     s_planned_kind_inv == ~s_planned_kind &&
                     (s_planned_kind == M2S_DIAG_RESTART_SUPLA ||
                      s_planned_kind == M2S_DIAG_RESTART_FACTORY));
    s_last_planned_kind = s_was_planned ? (unsigned)s_planned_kind : 0U;
    s_magic = 0;
    s_magic_inv = 0;
    s_planned_kind = 0;
    s_planned_kind_inv = 0;
    ESP_LOGW("M2S_S717", "BOOT_RESET reason=%s code=%d planned=%d cause=%s",
             m2s_diag_reset_reason(), (int)s_reason, (int)s_was_planned,
             m2s_diag_planned_reason());
}
