// Native ESP-IDF component: deliberately has no Arduino component dependency.
#include "m2s_supla.h"
#include "m2s_network.h"
#include "m2s_devices.h"
#include "m2s_readings.h"
#include "m2s_ikea_catalog.h"
#include "m2s_matter_api.h"
#include "m2s_ble_scan.h"
#include <SuplaDevice.h>
#include <supla/protocol/protocol_layer.h>
#include <supla/network/network.h>
#include <supla/sensor/virtual_therm_hygro_meter.h>
#include <supla/channels/channel.h>
#include <supla/sensor/virtual_binary.h>
#include <supla/sensor/general_purpose_measurement.h>
#include <esp_idf_client.h>
#include "esp_wifi.h"
#include "esp_netif.h"
#include "esp_sntp.h"
#include "esp_timer.h"
#include "esp_random.h"
#include "esp_system.h"
#include "esp_log.h"
#include "esp_heap_caps.h"
#include "m2s_diag.h"
#include <supla-common/proto.h>
#include "nvs.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "freertos/queue.h"
#include <cstring>
#include <cstdio>
#include <ctime>
#include <cctype>
#include <new>
#include <cmath>
namespace {
constexpr char TAG[]="M2S_SUPLA";
struct Config {
 uint32_t magic=0x4d325331;
 uint32_t node=0;
 uint16_t temp_ep=1,hum_ep=2;
 uint8_t enabled=0,reserved[3]{};
 char server[128]{},email[128]{};
 char guid[SUPLA_GUID_SIZE]{},auth[SUPLA_AUTHKEY_SIZE]{};
};
Config config;
// M2S7 saved exactly six slots. Keep this structure for non-destructive migration.
struct LegacySlotStore {
 uint32_t magic=0x4d325337;
 uint8_t count=0;
 uint8_t reserved[3]{};
 m2s_supla_sensor_slot_t slots[6]{};
};
// New format has 127 slots, stored separately in NVS. Original key is untouched.
struct SlotStore {
 uint32_t magic=0x4d325338; // M2S8, version 2 of channel map.
 uint16_t count=0;
 uint16_t reserved=0;
 m2s_supla_sensor_slot_t slots[M2S_SUPLA_EXTRA_LIMIT]{};
};
static_assert(M2S_SUPLA_EXTRA_LIMIT+1<=SUPLA_CHANNELMAXCOUNT,
              "Too many channels for SUPLA protocol");
// Stage11E: one-time caption registry, separate from the channel map.
// Channel 0 and pre-existing channels are never implicitly pending.
struct CaptionRegistry {
 uint32_t magic=0x4d324331; // M2C1
 uint16_t version=1;
 uint16_t reserved=0;
 uint8_t pending[16]{};
 uint8_t completed[16]{};
};
static_assert(sizeof(CaptionRegistry)==40,"Unexpected caption registry layout");
CaptionRegistry caption_registry{};
bool caption_registry_valid=false;

SlotStore *slot_store=nullptr;
SlotStore *make_store(){
 void *p=heap_caps_calloc(1,sizeof(SlotStore),MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
 if(!p)return nullptr;
 return new(p) SlotStore;
}
bool slots_corrupt=false;
portMUX_TYPE mux=portMUX_INITIALIZER_UNLOCKED;
StaticSemaphore_t config_guard_storage;
SemaphoreHandle_t config_guard=nullptr;

// Stage11E: bounded acknowledgement queue for SUPLA caption results.
struct CaptionAck {
 uint8_t channel=0;
 uint8_t result=0;
 uint8_t size=0;
 char caption[96]{};
};
StaticQueue_t caption_ack_queue_storage{};
alignas(4) uint8_t caption_ack_data[4*sizeof(CaptionAck)]{};
QueueHandle_t caption_ack_queue=nullptr;

m2s_supla_status_t state{};
// Access under config_guard when changed; network tick owns lifecycle.
static bool rc47d_worker_started=false;
static bool rc47d_boot_has_slots=false;
esp_timer_handle_t restart_timer=nullptr;

// Stage11E: persist a one-shot caption attempt before network transmission.
// completed means attempted, not necessarily acknowledged by the server.
bool m2s_stage11e_claim_caption(unsigned channel){
 if(channel==0 || channel>=128 || !config_guard)return false;
 const unsigned byte=channel/8;
 const uint8_t bit=static_cast<uint8_t>(1u<<(channel%8));

 xSemaphoreTake(config_guard,portMAX_DELAY);
 if(!caption_registry_valid || !slot_store || slots_corrupt ||
    channel>slot_store->count ||
    !(caption_registry.pending[byte]&bit) ||
    (caption_registry.completed[byte]&bit)){
  xSemaphoreGive(config_guard);
  return false;
 }

 CaptionRegistry next=caption_registry;
 next.pending[byte]&=static_cast<uint8_t>(~bit);
 next.completed[byte]|=bit;

 nvs_handle_t h;
 esp_err_t e=nvs_open("m2s_ikea",NVS_READWRITE,&h);
 if(e==ESP_OK){
  e=nvs_set_blob(h,"captions1",&next,sizeof(next));
  if(e==ESP_OK)e=nvs_commit(h);
  nvs_close(h);
 }
 if(e==ESP_OK){
  caption_registry=next;
  ESP_LOGI(TAG,"Stage11E: caption attempt persisted for channel %u",channel);
 }else{
  ESP_LOGE(TAG,"Stage11E: caption attempt NVS error %s",esp_err_to_name(e));
 }
 xSemaphoreGive(config_guard);
 return e==ESP_OK;
}

// Stage11E: synchronized, nonblocking caption permission check.
bool m2s_stage11e_caption_is_pending(unsigned channel){
 if(channel==0 || channel>=128 || !config_guard)return false;
 if(xSemaphoreTake(config_guard,0)!=pdTRUE)return false;

 const unsigned byte=channel/8;
 const uint8_t bit=static_cast<uint8_t>(1u<<(channel%8));
 const bool pending=caption_registry_valid &&
                    !slots_corrupt &&
                    slot_store &&
                    channel<=slot_store->count &&
                    (caption_registry.pending[byte]&bit)!=0 &&
                    (caption_registry.completed[byte]&bit)==0;

 xSemaphoreGive(config_guard);
 return pending;
}

// Stage11E: verify that a one-shot caption attempt was persisted.
bool m2s_stage11e_caption_was_claimed(unsigned channel){
 if(channel==0 || channel>=128 || !config_guard)return false;
 xSemaphoreTake(config_guard,portMAX_DELAY);

 const unsigned byte=channel/8;
 const uint8_t bit=static_cast<uint8_t>(1u<<(channel%8));
 const bool claimed=caption_registry_valid &&
                    !slots_corrupt &&
                    slot_store &&
                    channel<=slot_store->count &&
                    (caption_registry.completed[byte]&bit)!=0 &&
                    (caption_registry.pending[byte]&bit)==0;

 xSemaphoreGive(config_guard);
 return claimed;
}

// Stage11E: send a caption only after a durable one-shot claim.
bool m2s_stage11e_send_caption(unsigned channel,
                              const char *caption,
                              size_t caption_capacity){
 if(channel==0 || channel>=128 || !caption || caption_capacity==0)
  return false;

 const size_t len=strnlen(caption,caption_capacity);
 if(len==0 || len>=caption_capacity || len>=SUPLA_CAPTION_MAXSIZE)
  return false;

 auto *proto=Supla::Protocol::ProtocolLayer::first();
 if(!proto || !proto->isRegisteredAndReady())return false;

 // Persist the attempt before sending. Never resend after reboot.
 if(!m2s_stage11e_claim_caption(channel))return false;

 const bool sent=proto->setInitialCaption(
     static_cast<uint8_t>(channel),caption);
 ESP_LOGI(TAG,"Stage11E: caption channel=%u queued=%d",
          channel,(int)sent);
 return sent;
}


void info(int status,const char *message){
 portENTER_CRITICAL(&mux);state.status=status;state.online=status==STATUS_REGISTERED_AND_READY;
 snprintf(state.message,sizeof(state.message),"%s",message?message:"");portEXIT_CRITICAL(&mux);
 ESP_LOGI(TAG,"status=%d %s",status,message?message:"");
}
void reboot(void*){m2s_diag_mark_planned_restart(M2S_DIAG_RESTART_SUPLA);esp_restart();}
bool known_node(uint32_t node){m2s_device_t list[M2S_DEVICE_LIMIT]{};size_t n=m2s_devices_snapshot(list,M2S_DEVICE_LIMIT);for(size_t i=0;i<n;i++)if(list[i].node==node && (list[i].state==0||list[i].state==2))return true;return false;}
bool supported_slot(const m2s_supla_sensor_slot_t &slot,M2sIkeaSensor sensor){
 switch(slot.type){
 case M2S_SUPLA_SENSOR_TH:return sensor==M2sIkeaSensor::ThermHygro||sensor==M2sIkeaSensor::AirQuality;
 case M2S_SUPLA_SENSOR_MOTION:return sensor==M2sIkeaSensor::Motion;
 case M2S_SUPLA_SENSOR_CONTACT:return sensor==M2sIkeaSensor::Contact;
 case M2S_SUPLA_SENSOR_LEAK:return sensor==M2sIkeaSensor::WaterLeak;
 case M2S_SUPLA_SENSOR_CO2:case M2S_SUPLA_SENSOR_PM25:return sensor==M2sIkeaSensor::AirQuality;
 default:return false;
 }
}
// S7.12: channel captions use the Matter model name and a stable per-model
// index when two or more distinct nodes of the model have SUPLA channels.
// Index order is append-only SUPLA slot order, not volatile discovery order.
 // Do not count each measurement channel as a separate sensor.
static bool m2s_s712_model_for_node(uint32_t node, M2sIkeaSensor *model) {
 if(!model) return false;
 m2s_readings_t readings{};
 if(!m2s_readings_cached(node,&readings) ||
    !readings.vendor_valid || !readings.product_valid) return false;
 *model=m2s_ikea_sensor(readings.vendor_id,readings.product_id);
 return *model!=M2sIkeaSensor::Unknown;
}
static void m2s_stage11e_caption(char *out, size_t size,
 M2sIkeaSensor model, uint8_t type, uint32_t node, const SlotStore *slots) {
 const char *name=m2s_ikea_sensor_name(model);
 const char *kind="Czujnik";
 switch(type){
 case M2S_SUPLA_SENSOR_TH: kind="Temperatura i wilgotność"; break;
 case M2S_SUPLA_SENSOR_MOTION: kind="Ruch"; break;
 case M2S_SUPLA_SENSOR_CONTACT: kind="Otwarcie"; break;
 case M2S_SUPLA_SENSOR_LEAK: kind="Zalanie"; break;
 case M2S_SUPLA_SENSOR_CO2: kind="CO2"; break;
 case M2S_SUPLA_SENSOR_PM25: kind="PM2.5"; break;
 }
 unsigned count=0,rank=0;
 if(slots){
  for(unsigned i=0;i<slots->count;i++){
   const uint32_t candidate=slots->slots[i].node;
   if(candidate==0)continue;
   // First appearance of a Matter node in the immutable slot map wins.
   bool already_seen=false;
   for(unsigned j=0;j<i;j++){
    if(slots->slots[j].node==candidate){already_seen=true;break;}
   }
   if(already_seen)continue;
   M2sIkeaSensor other=M2sIkeaSensor::Unknown;
   if(!m2s_s712_model_for_node(candidate,&other) || other!=model)continue;
   ++count;
   if(candidate==node)rank=count;
  }
 }
 if(count>=2 && rank>0)
  snprintf(out,size,"%s %u - %s",name,rank,kind);
 else
  snprintf(out,size,"%s - %s",name,kind);
}

bool fresh_value(const m2s_readings_t &r,uint16_t ep,uint32_t cluster,int64_t now,int *result){
 for(int i=0;i<r.count;i++){
  const auto &v=r.values[i];
  if(v.valid && v.endpoint==ep && v.cluster==cluster && now>=v.received_us &&
     now-v.received_us<900000000LL){*result=v.value;return true;}
 }
 return false;
}
// Stage11D: validate ALPSTUGA readings before automatic SUPLA mapping.
bool alpstuga_ready(const m2s_readings_t &r,uint16_t ep,int64_t now){
 if(!r.vendor_valid||!r.product_valid||
    m2s_ikea_sensor(r.vendor_id,r.product_id)!=M2sIkeaSensor::AirQuality)
   return false;
 int value=0;
 return fresh_value(r,ep,0x0402,now,&value) &&
        fresh_value(r,ep,0x0405,now,&value) &&
        fresh_value(r,ep,0x040D,now,&value) &&
        fresh_value(r,ep,0x042A,now,&value);
}


// Stage11E: discover only sensor channels confirmed by recent Matter reports.
// Returns proposed slots; does not write NVS or change channel identities.
static unsigned m2s_stage11e_detect_slots(
    const m2s_readings_t &r, int64_t now,
    m2s_supla_sensor_slot_t *out, unsigned capacity) {
 if(!out||!capacity||!r.node||!r.vendor_valid||!r.product_valid)return 0;
 const auto model=m2s_ikea_sensor(r.vendor_id,r.product_id);
 if(model==M2sIkeaSensor::Unknown)return 0;
 unsigned count=0;
 auto append=[&](uint8_t type,uint16_t ep,uint16_t aux){
  if(count>=capacity)return;
  m2s_supla_sensor_slot_t slot{};
  slot.node=r.node;slot.type=type;slot.endpoint=ep;slot.aux_endpoint=aux;
  if(supported_slot(slot,model))out[count++]=slot;
 };
 auto endpoint_for=[&](uint32_t cluster)->uint16_t{
  int value=0;
  for(int i=0;i<r.count;i++){
   const auto &v=r.values[i];
   if(v.valid&&v.cluster==cluster&&
      fresh_value(r,v.endpoint,cluster,now,&value))
    return v.endpoint;
  }
  return 0xffff;
 };
 if(model==M2sIkeaSensor::ThermHygro||
    model==M2sIkeaSensor::AirQuality){
  const uint16_t temp=endpoint_for(0x0402);
  const uint16_t hum=endpoint_for(0x0405);
  if(temp!=0xffff&&hum!=0xffff)
   append(M2S_SUPLA_SENSOR_TH,temp,hum);
 }
 if(model==M2sIkeaSensor::AirQuality){
  const uint16_t co2=endpoint_for(0x040D);
  const uint16_t pm25=endpoint_for(0x042A);
  if(co2!=0xffff)append(M2S_SUPLA_SENSOR_CO2,co2,co2);
  if(pm25!=0xffff)append(M2S_SUPLA_SENSOR_PM25,pm25,pm25);
 }
 if(model==M2sIkeaSensor::Motion){
  const uint16_t ep=endpoint_for(0x0406);
  if(ep!=0xffff)append(M2S_SUPLA_SENSOR_MOTION,ep,ep);
 }
 if(model==M2sIkeaSensor::Contact||
    model==M2sIkeaSensor::WaterLeak){
  const uint16_t ep=endpoint_for(0x0045);
  if(ep!=0xffff)
   append(model==M2sIkeaSensor::Contact?
          M2S_SUPLA_SENSOR_CONTACT:M2S_SUPLA_SENSOR_LEAK,ep,ep);
 }
 // RC47D.2: exact VID/PID is mandatory. Use tested endpoint profiles only
 // when a recent measurement has not yet arrived. Existing slots are never
 // rewritten; a fresh report above always takes precedence.
 if(count==0){
  switch(model){
  case M2sIkeaSensor::Contact: append(M2S_SUPLA_SENSOR_CONTACT,1,1); break;
  case M2sIkeaSensor::Motion: append(M2S_SUPLA_SENSOR_MOTION,2,2); break;
  case M2sIkeaSensor::ThermHygro:
   // Prefer any endpoint already confirmed by a recent report.
   {const uint16_t t=endpoint_for(0x0402),h=endpoint_for(0x0405);
    append(M2S_SUPLA_SENSOR_TH,t==0xffff?1:t,h==0xffff?2:h);}
   break;
  default: break; // ALPSTUGA/KLIPPBOK and unknown devices keep legacy validation.
  }
 }
 return count;
}

void apply_battery(Supla::Channel *ch,const m2s_readings_t &r,int64_t now){
 if(r.battery_valid && r.battery_raw<=200 && now>=r.battery_received_us &&
    now-r.battery_received_us<86400000000LL){
  ch->setBatteryPowered(true);ch->setBatteryLevel((r.battery_raw+1)/2);
 }
}
struct ExtraChannel {
 Supla::Sensor::VirtualThermHygroMeter *thermo=nullptr;
 Supla::Sensor::VirtualBinary *binary=nullptr;
 Supla::Sensor::GeneralPurposeMeasurement *scalar=nullptr;
 Supla::Channel *channel=nullptr;
 int8_t last_binary=-1; // Volatile: -1=unknown, 0=clear, 1=alarm.
};
class ExistingWifi final:public Supla::Network {
public:
 void setup()override{} // m2s_network is the sole owner of the Wi-Fi driver.
 void disable()override{}
 void uninit()override{}
 void setConfigMode()override{}
 void setNormalMode()override{}
 void setOfflineMode()override{}
 bool isWifiConfigRequired()override{return false;}
 bool isReady()override{m2s_network_status_t s{};m2s_network_status(&s);return s.connected&&!s.ap_active&&!s.testing;}
 bool getMacAddr(uint8_t *mac)override{return esp_wifi_get_mac(WIFI_IF_STA,mac)==ESP_OK;}
 uint32_t getIP()override{auto *n=esp_netif_get_handle_from_ifkey("WIFI_STA_DEF");esp_netif_ip_info_t ip{};return n&&esp_netif_get_ip_info(n,&ip)==ESP_OK?ip.ip.addr:0;}
 Supla::Client *createClient()override{return new(std::nothrow) Supla::EspIdfClient;}
};
void worker(void*){
 // Copy immutable running configuration. Saved changes take effect only after reboot.
 Config running;
 SlotStore *runningSlots=make_store();
 if(!runningSlots){info(-103,"Brak PSRAM na konfiguracje kanalow SUPLA");for(;;)vTaskDelay(pdMS_TO_TICKS(1000));}
 xSemaphoreTake(config_guard,portMAX_DELAY);
 running=config;
 if(slot_store)*runningSlots=*slot_store;
 xSemaphoreGive(config_guard);
 if(slots_corrupt){info(-106,"Niezgodna konfiguracja kanalow; nie rejestruje SUPLA");for(;;)vTaskDelay(pdMS_TO_TICKS(1000));}
 ExistingWifi wifi;
 bool time_started=false;
 const int64_t waitStartedUs=esp_timer_get_time();
 int64_t nextClockReportUs=waitStartedUs;
 while(!wifi.isReady() || time(nullptr)<1704067200){
   if(wifi.isReady()&&!time_started){
     if(!esp_sntp_enabled()){esp_sntp_setoperatingmode(SNTP_OPMODE_POLL);esp_sntp_setservername(0,"time.cloudflare.com");esp_sntp_init();}
     time_started=true;info(-101,"Oczekiwanie na synchronizacje czasu dla TLS");
   }
   const int64_t nowUs=esp_timer_get_time();
   if(nowUs>=nextClockReportUs){
     nextClockReportUs=nowUs+15000000LL;
     ESP_LOGI(TAG,"CLOCK_WAIT elapsed_s=%lld epoch=%lld wifi_ready=%d sntp_started=%d DMA=%u DMA_largest=%u",
      (long long)((nowUs-waitStartedUs)/1000000LL),(long long)time(nullptr),
      (int)wifi.isReady(),(int)time_started,
      (unsigned)heap_caps_get_free_size(MALLOC_CAP_DMA),
      (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_DMA));
   }
   vTaskDelay(pdMS_TO_TICKS(250));
 }
 ESP_LOGI(TAG,"CLOCK_READY elapsed_s=%lld epoch=%lld",
  (long long)((esp_timer_get_time()-waitStartedUs)/1000000LL),
  (long long)time(nullptr));
 // Delay TLS until Matter startup allocations have settled.

 // M2S-NOCH0-V2: omit phantom TH channel 0, preserve explicit slot numbers.
 Supla::Channel::setStartingChannelNumber(1);
 ESP_LOGI(TAG,"SUPLA: omit synthetic channel 0; keep %u mapped slots",
          (unsigned)runningSlots->count);
 ExtraChannel *extra=nullptr;
 if(runningSlots->count){
   extra=static_cast<ExtraChannel*>(heap_caps_calloc(
      runningSlots->count,sizeof(ExtraChannel),MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT));
   if(!extra){info(-103,"Brak PSRAM na kanaly SUPLA");for(;;)vTaskDelay(pdMS_TO_TICKS(1000));}
 }
 // Channel IDs 1..N are explicit and append-only, never repurposed after NVS save.
 for(unsigned i=0;i<runningSlots->count;i++){
   const auto &slot=runningSlots->slots[i];
   ExtraChannel &ch=extra[i];
   char caption[96]{};
   m2s_readings_t captionReadings{};
   M2sIkeaSensor captionModel=M2sIkeaSensor::Unknown;
   if(m2s_readings_cached(slot.node,&captionReadings) &&
      captionReadings.vendor_valid && captionReadings.product_valid){
     captionModel=m2s_ikea_sensor(captionReadings.vendor_id,
                                  captionReadings.product_id);
   }
   if(captionModel!=M2sIkeaSensor::Unknown)
     m2s_stage11e_caption(caption,sizeof(caption),captionModel,slot.type,slot.node,runningSlots);
   if(slot.type==M2S_SUPLA_SENSOR_TH){
     ch.thermo=new(std::nothrow) Supla::Sensor::VirtualThermHygroMeter;
     if(ch.thermo){ch.thermo->setRefreshIntervalMs(1000);if(false && caption[0])ch.thermo->setInitialCaption(caption);ch.channel=ch.thermo->getChannel();}
   }else if(slot.type==M2S_SUPLA_SENSOR_MOTION||slot.type==M2S_SUPLA_SENSOR_CONTACT||slot.type==M2S_SUPLA_SENSOR_LEAK){
     ch.binary=new(std::nothrow) Supla::Sensor::VirtualBinary;
      if(ch.binary){
        ch.binary->setUseConfiguredTimeout(false);
        // Stage11E MYGGBETT: a binary channel with Function=None is hidden in SUPLA clients.
        // Set a DEFAULT function only; do not change the stable channel type/number or NVS map.
        // Existing SUPLA Cloud channel functions still need to be configured in Cloud if None.
        if(slot.type==M2S_SUPLA_SENSOR_CONTACT){
          ch.binary->setDefaultFunction(SUPLA_CHANNELFNC_OPENINGSENSOR_DOOR);
          ESP_LOGI(TAG,"MYGGBETT DEFAULT channel=%u node=%lu ep=%u function=OPENINGSENSOR_DOOR",
                   i+1,(unsigned long)slot.node,(unsigned)slot.endpoint);
        }
        ch.channel=ch.binary->getChannel();
        if(false && caption[0])ch.binary->setInitialCaption(caption);
      }
   }else if(slot.type==M2S_SUPLA_SENSOR_CO2||slot.type==M2S_SUPLA_SENSOR_PM25){
     ch.scalar=new(std::nothrow) Supla::Sensor::GeneralPurposeMeasurement;
     if(ch.scalar){if(false && caption[0])ch.scalar->setInitialCaption(caption);
       ch.scalar->setDefaultUnitAfterValue(slot.type==M2S_SUPLA_SENSOR_CO2?"ppm":"ug/m3");
       ch.scalar->setDefaultValuePrecision(1);ch.channel=ch.scalar->getChannel();}
   }
   if(!ch.channel){info(-103,"Za malo RAM na dodatkowy kanal SUPLA");for(;;)vTaskDelay(pdMS_TO_TICKS(1000));}
   if(!ch.channel->setChannelNumber(static_cast<int>(i+1))){
     info(-103,"Nie mozna przypisac numeru dodatkowego kanalu SUPLA");
     for(;;)vTaskDelay(pdMS_TO_TICKS(1000));
   }
   // M2S-SUPLA-CAPTION-V3: name from the paired Matter registry.
   // Duplicate suffix applies to distinct mapped Matter nodes, not channels.
   {
     m2s_device_t caption_nodes[M2S_DEVICE_LIMIT]{};
     const size_t caption_count=m2s_devices_snapshot(caption_nodes,M2S_DEVICE_LIMIT);
     const char *caption_name=nullptr;
     for(size_t j=0;j<caption_count;j++){
       if(caption_nodes[j].node==slot.node && caption_nodes[j].name[0]){
         caption_name=caption_nodes[j].name;
         break;
       }
     }
     char caption_fallback[32]{};
     if(!caption_name){
       snprintf(caption_fallback,sizeof(caption_fallback),"Matter %lu",(unsigned long)slot.node);
       caption_name=caption_fallback;
     }
     const char *caption_type="Czujnik";
     switch(slot.type){
       case M2S_SUPLA_SENSOR_CONTACT: caption_type="Czujnik Otwarcia";break;
       case M2S_SUPLA_SENSOR_LEAK: caption_type="Czujnik Zalania";break;
       case M2S_SUPLA_SENSOR_MOTION: caption_type="Czujnik Ruchu";break;
       case M2S_SUPLA_SENSOR_TH: caption_type="Czujnik Temperatury i Wilgotności";break;
       case M2S_SUPLA_SENSOR_CO2: caption_type="Czujnik CO2";break;
       case M2S_SUPLA_SENSOR_PM25: caption_type="Czujnik PM2.5";break;
       default:break;
     }
     // Number only when another *distinct* Matter node of the same name is
     // assigned to any SUPLA slot; multiple ALPSTUGA channels count as one.
     bool caption_duplicate=false;
     unsigned caption_rank=1;
     for(size_t j=0;j<caption_count;j++){
       if(caption_nodes[j].node==slot.node ||
          !caption_nodes[j].name[0] ||
          strcmp(caption_nodes[j].name,caption_name)!=0)continue;
       bool mapped=false;
       for(unsigned k=0;k<runningSlots->count;k++){
         if(runningSlots->slots[k].node==caption_nodes[j].node){mapped=true;break;}
       }
       if(!mapped)continue;
       caption_duplicate=true;
       if(caption_nodes[j].node<slot.node)caption_rank++;
     }
     char caption_text[128]{};
     if(caption_duplicate){
       snprintf(caption_text,sizeof(caption_text),"%s %u: %s",
                caption_name,caption_rank,caption_type);
     }else{
       snprintf(caption_text,sizeof(caption_text),"%s: %s",
                caption_name,caption_type);
     }
     ch.channel->setInitialCaption(caption_text);
     ESP_LOGI(TAG,"SUPLA caption ch=%u node=%lu: %s",
              (unsigned)(i+1),(unsigned long)slot.node,caption_text);
   }
    ch.channel->setStateOffline();
    ESP_LOGI(TAG,"SUPLA_SLOT_REGISTER channel=%u node=%lu type=%u endpoint=%u aux=%u invert=%u",
             i+1,(unsigned long)slot.node,(unsigned)slot.type,
             (unsigned)slot.endpoint,(unsigned)slot.aux_endpoint,(unsigned)slot.invert);
  }
  SuplaDevice.setName("Matter2Supla");SuplaDevice.setSwVersion("0.9.3-11E-RT1");
 SuplaDevice.setStatusFuncImpl(info);SuplaDevice.setServerPort(2016);
 ESP_LOGI(TAG,"before TLS: epoch=%lld CA=%s internal=%u largest=%u DMA=%u DMA_largest=%u psram=%u",
  (long long)time(nullptr),
  SuplaDevice.getSuplaCACert()?"PRESENT":"MISSING",
  (unsigned)heap_caps_get_free_size(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT),
  (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT),
  (unsigned)heap_caps_get_free_size(MALLOC_CAP_DMA),
  (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_DMA),
  (unsigned)heap_caps_get_free_size(MALLOC_CAP_SPIRAM));
 if(!SuplaDevice.begin(running.guid,running.server,running.email,running.auth)){
   info(-102,"Nie udalo sie uruchomic SUPLA; sprawdz log");
   for(;;)vTaskDelay(pdMS_TO_TICKS(1000));
 }
 int64_t next_update=0;
 int64_t next_contact_update=0;
 while(true){
   const int64_t now=esp_timer_get_time();
   if(now>=next_update){
     next_update=now+1000000;
     // M2S-NOCH0-V2: only mapped Matter-to-SUPLA slots 1..N.
     for(unsigned i=0;i<runningSlots->count;i++){
       const auto &slot=runningSlots->slots[i];const auto &ch=extra[i];
       // Event-like sensors have a dedicated 150-ms path below.
       if(slot.type==M2S_SUPLA_SENSOR_CONTACT ||
          slot.type==M2S_SUPLA_SENSOR_MOTION ||
          slot.type==M2S_SUPLA_SENSOR_LEAK)continue;
       m2s_readings_t sr{};bool available=known_node(slot.node) && m2s_readings_cached(slot.node,&sr);
       if(!available||!sr.vendor_valid||!sr.product_valid||
          !supported_slot(slot,m2s_ikea_sensor(sr.vendor_id,sr.product_id))){
         ch.channel->setStateOffline();continue;
       }
       int v=0,other=0;bool valid=false;
       if(ch.thermo){
         const bool t_ok=fresh_value(sr,slot.endpoint,0x0402,now,&v);
         const bool h_ok=fresh_value(sr,slot.aux_endpoint,0x0405,now,&other);
         ch.thermo->setTemp(t_ok?v/100.0:TEMPERATURE_NOT_AVAILABLE);
         ch.thermo->setHumi(h_ok?other/100.0:HUMIDITY_NOT_AVAILABLE);
         valid=t_ok&&h_ok;
       }else if(ch.binary){
         const uint32_t cluster=slot.type==M2S_SUPLA_SENSOR_MOTION?0x0406:0x0045;
         valid=fresh_value(sr,slot.endpoint,cluster,now,&v);
         if(valid){if((v!=0)!=bool(slot.invert))ch.binary->set();else ch.binary->clear();}
       }else if(ch.scalar){
         const uint32_t cluster=slot.type==M2S_SUPLA_SENSOR_CO2?0x040D:0x042A;
         valid=fresh_value(sr,slot.endpoint,cluster,now,&v);
         if(valid)ch.scalar->setValue(v/100.0);
       }
       if(valid){apply_battery(ch.channel,sr,now);ch.channel->setStateOnline();}
       else ch.channel->setStateOffline();
     }
   }
   // Binary Matter reports: transfer state to SUPLA on the 150-ms
   // tick, independent of the 1-second T/H/scalar refresh interval.
   // Contact: 0=open (alarm). Motion/WaterLeak: 1=detected (alarm).
   if(now>=next_contact_update){
     next_contact_update=now+150000LL;
     for(unsigned i=0;i<runningSlots->count;i++){
       const auto &slot=runningSlots->slots[i];
       if(slot.type!=M2S_SUPLA_SENSOR_CONTACT &&
          slot.type!=M2S_SUPLA_SENSOR_MOTION &&
          slot.type!=M2S_SUPLA_SENSOR_LEAK)continue;
       auto &ch=extra[i];
       if(!ch.binary || !ch.channel)continue;
       m2s_readings_t sr{};
       const bool available=known_node(slot.node) && m2s_readings_cached(slot.node,&sr);
       const bool identified=available && sr.vendor_valid && sr.product_valid &&
         supported_slot(slot,m2s_ikea_sensor(sr.vendor_id,sr.product_id));
       const uint32_t cluster=(slot.type==M2S_SUPLA_SENSOR_MOTION)?0x0406:0x0045;
       int v=0;
       if(!identified || !fresh_value(sr,slot.endpoint,cluster,now,&v)){
         if(ch.last_binary!=-1)ch.channel->setStateOffline();
         ch.last_binary=-1;
         continue;
       }
       bool alarm=(slot.type==M2S_SUPLA_SENSOR_CONTACT)?(v==0):(v!=0);
       alarm=alarm!=bool(slot.invert);
       if(ch.last_binary!=static_cast<int8_t>(alarm)){
         ESP_LOGI(TAG,"BINARY_SUPLA node=%lu channel=%u ep=%u type=%u alarm=%u",
                  (unsigned long)slot.node,i+1,(unsigned)slot.endpoint,
                  (unsigned)slot.type,(unsigned)alarm);
         ch.last_binary=static_cast<int8_t>(alarm);
         if(alarm)ch.binary->set();else ch.binary->clear();
       }
       apply_battery(ch.channel,sr,now);
       ch.channel->setStateOnline();
     }
   }
   SuplaDevice.iterate();
    // Stage11E: process server caption acknowledgements outside SRPC callback.
    if(caption_ack_queue){
      CaptionAck ack{};
      while(xQueueReceive(caption_ack_queue,&ack,0)==pdTRUE){
        if(ack.channel==0 || ack.channel>runningSlots->count)
          continue;

        if(!m2s_stage11e_caption_was_claimed(ack.channel))
          continue;

        const auto &slot=runningSlots->slots[ack.channel-1];
        m2s_readings_t readings{};

        if(!m2s_readings_cached(slot.node,&readings) ||
           !readings.vendor_valid || !readings.product_valid)
          continue;

        const auto model=m2s_ikea_sensor(
            readings.vendor_id,readings.product_id);

        if(model==M2sIkeaSensor::Unknown ||
           !supported_slot(slot,model))
          continue;

        char expected[96]{};
        m2s_stage11e_caption(
            expected,sizeof(expected),model,slot.type,slot.node,runningSlots);

        const size_t expected_len=strnlen(expected,sizeof(expected));

        if(expected_len==0 ||
           expected_len>=sizeof(expected) ||
           static_cast<size_t>(ack.size)!=expected_len+1 ||
           memcmp(ack.caption,expected,expected_len+1)!=0){
          ESP_LOGW(TAG,
              "Stage11E: caption ACK mismatch channel=%u",
              static_cast<unsigned>(ack.channel));
          continue;
        }

        if(ack.result==SUPLA_RESULTCODE_TRUE){
          ESP_LOGI(TAG,
              "Stage11E: caption confirmed channel=%u name=%s",
              static_cast<unsigned>(ack.channel),expected);
        }else{
          ESP_LOGW(TAG,
              "Stage11E: caption rejected channel=%u code=%u",
              static_cast<unsigned>(ack.channel),
              static_cast<unsigned>(ack.result));
        }
      }
    }


   // Stage11E: one-shot captions for newly discovered channels only.
   static int64_t next_caption_check=0;
   if(now>=next_caption_check){
    next_caption_check=now+3000000LL;
    auto *proto=Supla::Protocol::ProtocolLayer::first();
    if(proto && proto->isRegisteredAndReady()){
     for(unsigned i=0;i<runningSlots->count;i++){
      const unsigned channel=i+1;
      if(!m2s_stage11e_caption_is_pending(channel))continue;

      m2s_readings_t readings{};
      const auto &slot=runningSlots->slots[i];
      if(!m2s_readings_cached(slot.node,&readings) ||
         !readings.vendor_valid || !readings.product_valid)
       continue;

      const auto model=m2s_ikea_sensor(
          readings.vendor_id,readings.product_id);
      if(model==M2sIkeaSensor::Unknown ||
         !supported_slot(slot,model))
       continue;

      char caption[96]{};
      m2s_stage11e_caption(
          caption,sizeof(caption),model,slot.type,slot.node,runningSlots);
      if(caption[0] &&
         m2s_stage11e_send_caption(channel,caption,sizeof(caption)))
       break;
     }
    }
   }
   vTaskDelay(pdMS_TO_TICKS(20));
 }
}
}
extern "C" void m2s_stage11e_caption_result(
 unsigned char channel_number,
 unsigned char result_code,
 const char *caption,
 unsigned int caption_size){

 if(!caption_ack_queue || !caption ||
    channel_number==0 || channel_number>=128 ||
    caption_size==0 || caption_size>96)
  return;

 if(caption[caption_size-1]!='\0')return;

 CaptionAck event{};
 event.channel=channel_number;
 event.result=result_code;
 event.size=static_cast<uint8_t>(caption_size);
 memcpy(event.caption,caption,caption_size);

 // Called by SUPLA protocol task; never write NVS here.
 (void)xQueueSend(caption_ack_queue,&event,0);
}

extern "C" void m2s_supla_status(m2s_supla_status_t *out){portENTER_CRITICAL(&mux);*out=state;portEXIT_CRITICAL(&mux);}
extern "C" void m2s_supla_init(){
 config_guard=xSemaphoreCreateMutexStatic(&config_guard_storage);
 caption_ack_queue=xQueueCreateStatic(
     4,sizeof(CaptionAck),
     caption_ack_data,&caption_ack_queue_storage);
 if(!caption_ack_queue)
  ESP_LOGE(TAG,"Stage11E caption ACK queue unavailable");
 nvs_handle_t h;size_t size=sizeof(config);
 if(nvs_open("m2s_supla",NVS_READONLY,&h)==ESP_OK){
   auto e=nvs_get_blob(h,"config",&config,&size);nvs_close(h);
   if(e!=ESP_OK||size!=sizeof(config)||config.magic!=0x4d325331)config=Config{};
 }
 slot_store=make_store();
 if(!slot_store){slots_corrupt=true;ESP_LOGE(TAG,"No PSRAM for SUPLA channel store");}
 else if(nvs_open("m2s_ikea",NVS_READONLY,&h)==ESP_OK){
   size_t v2size=sizeof(*slot_store);
   esp_err_t e=nvs_get_blob(h,"channels2",slot_store,&v2size);
   if(e==ESP_ERR_NVS_NOT_FOUND){
     // Stage10F migration: previously stored maximum six slots.
     LegacySlotStore legacy{};
     size_t oldsize=sizeof(legacy);
     e=nvs_get_blob(h,"channels",&legacy,&oldsize);
     if(e==ESP_OK && oldsize==sizeof(legacy) && legacy.magic==0x4d325337 && legacy.count<=6){
       slot_store->count=legacy.count;
       for(unsigned i=0;i<legacy.count;i++)slot_store->slots[i]=legacy.slots[i];
       ESP_LOGI(TAG,"Migrated %u legacy SUPLA channels in memory",(unsigned)legacy.count);
     }else if(e!=ESP_ERR_NVS_NOT_FOUND){
       slots_corrupt=true;
       ESP_LOGE(TAG,"Bad legacy channel data, preserving NVS");
     }
   }else if(e!=ESP_OK || v2size!=sizeof(*slot_store) ||
            slot_store->magic!=0x4d325338 || slot_store->count>M2S_SUPLA_EXTRA_LIMIT){
     slots_corrupt=true;
     ESP_LOGE(TAG,"Bad v2 SUPLA channels, preserving NVS");
   }
   nvs_close(h);
 }
 // Stage11E: load caption registry without modifying existing NVS.
 caption_registry=CaptionRegistry{};
 caption_registry_valid=true;
 esp_err_t caption_open=nvs_open("m2s_ikea",NVS_READONLY,&h);
 if(caption_open==ESP_OK){
   CaptionRegistry loaded{};
   size_t caption_size=sizeof(loaded);
   const esp_err_t ce=nvs_get_blob(h,"captions1",&loaded,&caption_size);
   nvs_close(h);
   if(ce==ESP_OK && caption_size==sizeof(loaded) &&
      loaded.magic==0x4d324331 && loaded.version==1){
     caption_registry=loaded;
   }else if(ce!=ESP_ERR_NVS_NOT_FOUND){
     caption_registry_valid=false;
     ESP_LOGE(TAG,"Invalid caption registry; automatic naming disabled");
   }
 }else if(caption_open!=ESP_ERR_NVS_NOT_FOUND){
   caption_registry_valid=false;
   ESP_LOGE(TAG,"Cannot open caption registry; automatic naming disabled");
 }
 // Validate caption permissions against the append-only channel map.
 if(caption_registry_valid && slot_store && !slots_corrupt){
   for(unsigned channel=0;channel<128;channel++){
     const unsigned byte=channel/8;
     const uint8_t bit=static_cast<uint8_t>(1u<<(channel%8));
     const bool pending=(caption_registry.pending[byte]&bit)!=0;
     const bool completed=(caption_registry.completed[byte]&bit)!=0;
     if((pending && completed) ||
        ((pending || completed) && (channel==0 || channel>slot_store->count))){
       caption_registry_valid=false;
       ESP_LOGE(TAG,"Invalid caption flags for channel %u; naming disabled",channel);
       break;
     }
   }
 }
 // Channel zero must never be renamed automatically.
 caption_registry.pending[0]&=static_cast<uint8_t>(~1u);

 if(!slots_corrupt && slot_store)for(unsigned i=0;i<slot_store->count;i++){
   const auto &s=slot_store->slots[i];
   if(!s.node||s.node>65535||s.endpoint==65535||s.aux_endpoint==65535||
      s.type<M2S_SUPLA_SENSOR_TH||s.type>M2S_SUPLA_SENSOR_PM25||s.invert>1){
     slots_corrupt=true;
     ESP_LOGE(TAG,"Invalid saved IKEA channel; SUPLA registration blocked");break;
   }
 }
  rc47d_boot_has_slots=slot_store && !slots_corrupt && slot_store->count>0;
  ESP_LOGI(TAG,"SUPLA_NVS_MAP slots=%u corrupt=%d",slot_store?(unsigned)slot_store->count:0,
           (int)slots_corrupt);
  if(slot_store && !slots_corrupt){
    for(unsigned i=0;i<slot_store->count;i++){
      const auto &saved=slot_store->slots[i];
      if(saved.type==M2S_SUPLA_SENSOR_CONTACT){
        ESP_LOGI(TAG,"MYGGBETT NVS channel=%u node=%lu ep=%u invert=%u",
                 i+1,(unsigned long)saved.node,(unsigned)saved.endpoint,(unsigned)saved.invert);
      }
    }
  }
 config.server[127]=0;config.email[127]=0;
 state.enabled=config.enabled;state.configured=config.node!=0;state.node=config.node;
 state.temperature_endpoint=config.temp_ep;state.humidity_endpoint=config.hum_ep;
 snprintf(state.server,sizeof(state.server),"%s",config.server);snprintf(state.email,sizeof(state.email),"%s",config.email);
 snprintf(state.message,sizeof(state.message),"%s",config.enabled?"Oczekiwanie na Wi-Fi":"Integracja wylaczona");
 esp_timer_create_args_t timer{};timer.callback=reboot;timer.name="m2s_sup_reboot";
 if(esp_timer_create(&timer,&restart_timer)!=ESP_OK)restart_timer=nullptr;

}
extern "C" uint8_t m2s_supla_recovery_hint(uint32_t node){
 if(!config_guard || !slot_store || !node)return 0;
 if(xSemaphoreTake(config_guard,0)!=pdTRUE)return 0;
 uint8_t hint=0;
 if(!slots_corrupt && slot_store->count<=M2S_SUPLA_EXTRA_LIMIT){
   for(unsigned i=0;i<slot_store->count;i++){
     const auto &s=slot_store->slots[i];if(s.node!=node)continue;
     if(s.type==M2S_SUPLA_SENSOR_TH || s.type==M2S_SUPLA_SENSOR_MOTION ||
        s.type==M2S_SUPLA_SENSOR_CONTACT || s.type==M2S_SUPLA_SENSOR_LEAK){
       if(hint && hint!=s.type){hint=0;break;}hint=s.type;
     }
   }
 }
 xSemaphoreGive(config_guard);return hint;
}
extern "C" size_t m2s_supla_slots_snapshot(m2s_supla_sensor_slot_t *out,size_t capacity){
 if(!config_guard || !out || !slot_store)return 0;
 xSemaphoreTake(config_guard,portMAX_DELAY);
 const size_t count=capacity<slot_store->count?capacity:slot_store->count;
 for(size_t i=0;i<count;i++)out[i]=slot_store->slots[i];
 xSemaphoreGive(config_guard);return count;
}
extern "C" esp_err_t m2s_supla_add_sensor(uint32_t node,uint8_t type,uint16_t endpoint,uint16_t aux_endpoint,bool invert){
 if(!config_guard||!restart_timer||!slot_store||!node||node>65535||
    endpoint==65535||aux_endpoint==65535||!known_node(node))return ESP_ERR_INVALID_ARG;
 m2s_readings_t r{};
 if(!m2s_readings_cached(node,&r)||!r.vendor_valid||!r.product_valid)return ESP_ERR_INVALID_STATE;
 portENTER_CRITICAL(&mux);const bool supla_online=state.online;portEXIT_CRITICAL(&mux);
 if(!supla_online)return ESP_ERR_INVALID_STATE;
 m2s_supla_sensor_slot_t slot{};
 slot.node=node;slot.type=type;slot.endpoint=endpoint;slot.aux_endpoint=aux_endpoint;slot.invert=invert?1:0;
 if(!supported_slot(slot,m2s_ikea_sensor(r.vendor_id,r.product_id)))return ESP_ERR_INVALID_ARG;
 // Do not permanently register an empty channel just because a model supports
 // a class: the chosen endpoint must have yielded a recent valid attribute.
 const int64_t now=esp_timer_get_time();int value=0,other=0;
 bool seen=false;
 switch(type){
 case M2S_SUPLA_SENSOR_TH:
   seen=fresh_value(r,endpoint,0x0402,now,&value) &&
        fresh_value(r,aux_endpoint,0x0405,now,&other);break;
 case M2S_SUPLA_SENSOR_MOTION:seen=fresh_value(r,endpoint,0x0406,now,&value);break;
 case M2S_SUPLA_SENSOR_CONTACT:case M2S_SUPLA_SENSOR_LEAK:
   seen=fresh_value(r,endpoint,0x0045,now,&value);break;
 case M2S_SUPLA_SENSOR_CO2:seen=fresh_value(r,endpoint,0x040D,now,&value);break;
 case M2S_SUPLA_SENSOR_PM25:seen=fresh_value(r,endpoint,0x042A,now,&value);break;
 default:break;
 }
 if(!seen)return ESP_ERR_INVALID_STATE;
 xSemaphoreTake(config_guard,portMAX_DELAY);
 if(slots_corrupt||state.restart_required||slot_store->count>=M2S_SUPLA_EXTRA_LIMIT||
    !config.enabled||!config.node){xSemaphoreGive(config_guard);return ESP_ERR_INVALID_STATE;}
 // Reserve internal memory for Matter, SRPC/TLS and Thread. Hard-limit is
 // the SUPLA protocol; available RAM may force an earlier stop.
 if(heap_caps_get_free_size(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT)<10000 ||
    heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT)<1600){
   xSemaphoreGive(config_guard);return ESP_ERR_NO_MEM;
 }
 for(unsigned i=0;i<slot_store->count;i++){
  const auto &previous=slot_store->slots[i];
  if(previous.node==slot.node && previous.type==slot.type){
   xSemaphoreGive(config_guard);return ESP_ERR_INVALID_STATE;
  }
 }
 SlotStore *next=make_store();
 if(!next){xSemaphoreGive(config_guard);return ESP_ERR_NO_MEM;}
 *next=*slot_store;
 next->slots[next->count++]=slot;
 nvs_handle_t h;esp_err_t e=nvs_open("m2s_ikea",NVS_READWRITE,&h);
 if(e==ESP_OK){
   e=nvs_set_blob(h,"channels2",next,sizeof(*next));
   if(e==ESP_OK)e=nvs_commit(h);
   nvs_close(h);
 }
 if(e==ESP_OK){
   SlotStore *previous=slot_store;
   slot_store=next;
   heap_caps_free(previous);
   portENTER_CRITICAL(&mux);state.restart_required=true;portEXIT_CRITICAL(&mux);
   e=esp_timer_start_once(restart_timer,2000000);
   ESP_LOGI(TAG,"APPEND_CHANNEL number=%u node=%lu type=%u NVS=v2 reboot=%d",
     (unsigned)slot_store->count,(unsigned long)node,(unsigned)type,(int)e);
 }else heap_caps_free(next);
 xSemaphoreGive(config_guard);return e;
}
extern "C" esp_err_t m2s_supla_configure(bool enabled,const char *server,const char *email,uint32_t node,uint16_t temp_ep,uint16_t hum_ep){
 if(!config_guard||!restart_timer)return ESP_ERR_INVALID_STATE;
 if(!server||!email||strlen(server)>127||strlen(email)>127||!node||node>65535||temp_ep==65535||hum_ep==65535)return ESP_ERR_INVALID_ARG;
 const bool node_registered=known_node(node);
 if(!server[0]||!strchr(email,'@'))return ESP_ERR_INVALID_ARG;
 for(const unsigned char *p=(const unsigned char*)server;*p;p++)if(!isalnum(*p)&&*p!='.'&&*p!='-')return ESP_ERR_INVALID_ARG;
 for(const unsigned char *p=(const unsigned char*)email;*p;p++)if(*p<=32||*p>=127)return ESP_ERR_INVALID_ARG;
 xSemaphoreTake(config_guard,portMAX_DELAY);
 // Preserve original SUPLA channel 0 mapping.
 // An orphaned node may reconnect, but never be replaced.
 if(enabled && !node_registered &&
    (!config.node || config.node!=node)){
   xSemaphoreGive(config_guard);
   return ESP_ERR_INVALID_ARG;
 }
 if(state.restart_required){xSemaphoreGive(config_guard);return ESP_ERR_INVALID_STATE;}
 // A published channel never silently changes physical sensor or endpoint.
 if(config.node&&(config.node!=node||config.temp_ep!=temp_ep||config.hum_ep!=hum_ep)){xSemaphoreGive(config_guard);return ESP_ERR_INVALID_STATE;}
 Config next=config;next.node=node;next.temp_ep=temp_ep;next.hum_ep=hum_ep;next.enabled=enabled;
 snprintf(next.server,sizeof(next.server),"%s",server);snprintf(next.email,sizeof(next.email),"%s",email);
 if(!config.node){esp_fill_random(next.guid,sizeof(next.guid));esp_fill_random(next.auth,sizeof(next.auth));}
 nvs_handle_t h;esp_err_t e=nvs_open("m2s_supla",NVS_READWRITE,&h);
 if(e==ESP_OK){e=nvs_set_blob(h,"config",&next,sizeof(next));if(e==ESP_OK)e=nvs_commit(h);nvs_close(h);}
 if(e==ESP_OK){
   const bool first_config=!config.node && !rc47d_worker_started;
   config=next;
   if(first_config){
     portENTER_CRITICAL(&mux);
     state.enabled=config.enabled;state.configured=config.node!=0;state.node=config.node;
     state.temperature_endpoint=config.temp_ep;state.humidity_endpoint=config.hum_ep;
     snprintf(state.server,sizeof(state.server),"%s",config.server);
     snprintf(state.email,sizeof(state.email),"%s",config.email);
     snprintf(state.message,sizeof(state.message),"%s",config.enabled?"Oczekiwanie na SUPLA":"Integracja wylaczona");
     portEXIT_CRITICAL(&mux);
     ESP_LOGI(TAG,"RC47D4_FIRST_CONFIG_NO_REBOOT");
   }else{
     portENTER_CRITICAL(&mux);state.restart_required=true;portEXIT_CRITICAL(&mux);
     e=esp_timer_start_once(restart_timer,2000000);
   }
 }
 xSemaphoreGive(config_guard);return e;
}


// Stage11D: automatically append ALPSTUGA CO2 and PM2.5 channels.
// Never change existing channel identities or overwrite channel slots.
// Stage11E: preserve legacy ALPSTUGA humidity endpoint migration.
// Channel discovery and channel NVS writes are handled separately.
static void m2s_supla_alpstuga_auto(){
 static int64_t next_check=0;
 const int64_t now=esp_timer_get_time();
 if(now<next_check)return;
 next_check=now+10000000LL;

 if(!config_guard||!restart_timer||slots_corrupt)return;
 m2s_supla_status_t st{};
 m2s_supla_status(&st);
 if(!st.enabled||!st.configured||!st.online||st.restart_required)return;

 m2s_readings_t r{};
 if(!known_node(st.node)||!m2s_readings_cached(st.node,&r))return;

 bool ready=false;
 for(int i=0;i<r.count;i++){
  const auto &v=r.values[i];
  if(v.valid&&v.cluster==0x040D&&v.endpoint==1&&
     alpstuga_ready(r,1,now)){
   ready=true;break;
  }
 }
 if(!ready)return;

 xSemaphoreTake(config_guard,portMAX_DELAY);
 if(state.restart_required||config.node!=st.node||
    config.temp_ep!=1||config.hum_ep!=2){
  xSemaphoreGive(config_guard);
  return;
 }
 Config updated=config;
 updated.hum_ep=1;
 nvs_handle_t h;
 esp_err_t e=nvs_open("m2s_supla",NVS_READWRITE,&h);
 if(e==ESP_OK){
  e=nvs_set_blob(h,"config",&updated,sizeof(updated));
  if(e==ESP_OK)e=nvs_commit(h);
  nvs_close(h);
 }
 if(e==ESP_OK){
  config=updated;
  portENTER_CRITICAL(&mux);
  state.humidity_endpoint=1;
  state.restart_required=true;
  portEXIT_CRITICAL(&mux);
  ESP_LOGI(TAG,"Stage11E ALPSTUGA: humidity endpoint migrated 2->1");
  esp_timer_start_once(restart_timer,2000000);
 }
 xSemaphoreGive(config_guard);
}

// Stage11E: append newly discovered channels in one NVS transaction.
// RC4 candidate: conservative orphan guard. Never guess the identity of a
// re-paired Matter device from its name or sensor type alone. A stale SUPLA
// slot may own a Cloud ID/history and must not silently be replaced.
// NOTE: This can temporarily defer legitimate new devices of the same type;
// a reviewed, identity-aware migration is required to resolve that ambiguity.
static bool m2s_rc4_has_orphan_of_type(
    uint8_t type, const SlotStore &saved,
    const m2s_device_t *devices, size_t device_count) {
 for(unsigned k=0;k<saved.count;k++){
  const auto &old=saved.slots[k];
  if(old.type!=type)continue;
  bool present=false;
  for(size_t d=0;d<device_count;d++){
   if(devices[d].node==old.node){present=true;break;}
  }
  if(!present)return true;
 }
 return false;
}

// RC4 migration is EXPLICITLY OPT-IN after a complete flash/NVS backup.
// Set 1 only after verifying the physical sensors and Cloud channel history.
#ifndef M2S_RC4_ENABLE_MIGRATION
#define M2S_RC4_ENABLE_MIGRATION 1
#endif

#if M2S_RC4_ENABLE_MIGRATION
static bool m2s_rc4_identified(uint32_t node, const char *expected_name,
                               M2sIkeaSensor expected_model) {
 m2s_device_t *devices=static_cast<m2s_device_t *>(
     heap_caps_calloc(M2S_DEVICE_LIMIT,sizeof(m2s_device_t),MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT));
 if(!devices){ESP_LOGE(TAG,"RC42: identity snapshot PSRAM allocation failed");return false;}
 const size_t count=m2s_devices_snapshot(devices,M2S_DEVICE_LIMIT);
 bool found=false,invalid=false;
 for(size_t i=0;i<count;i++){
  if(devices[i].node!=node)continue;
  if(devices[i].state!=2 || strcmp(devices[i].name,expected_name)!=0){invalid=true;break;}
  found=true;
 }
 heap_caps_free(devices);
 if(invalid||!found)return false;
 m2s_readings_t r{};
 return m2s_readings_cached(node,&r) && r.vendor_valid && r.product_valid &&
        m2s_ikea_sensor(r.vendor_id,r.product_id)==expected_model;
}

// The same make_store() allocator used elsewhere in this component selects PSRAM.
// RAII guarantees release on every early return; no full SlotStore is on task stack.
struct Rc42HeapStore {
 Rc42HeapStore()=default;
 SlotStore *ptr=make_store();
 ~Rc42HeapStore(){if(ptr)heap_caps_free(ptr);}
 Rc42HeapStore(const Rc42HeapStore&)=delete;
 Rc42HeapStore& operator=(const Rc42HeapStore&)=delete;
};

// Backup blob and channel map are staged before a single nvs_commit().
static __attribute__((noinline)) bool m2s_rc4_commit_migration(const SlotStore &before,
                                    const SlotStore &after,
                                    const char *backup_key) {
 nvs_handle_t h;
 esp_err_t e=nvs_open("m2s_ikea",NVS_READWRITE,&h);
 if(e!=ESP_OK)return false;
 size_t existing=0;
 const esp_err_t prior=nvs_get_blob(h,backup_key,nullptr,&existing);
 if(prior!=ESP_ERR_NVS_NOT_FOUND){
  ESP_LOGW(TAG,"RC4: migration backup key already exists or unreadable; abort");
  nvs_close(h);return false;
 }
 Rc42HeapStore verify_buf;
 if(!verify_buf.ptr){ESP_LOGE(TAG,"RC42: verify store PSRAM allocation failed");nvs_close(h);return false;}
 SlotStore &verify=*verify_buf.ptr;
 size_t len=sizeof(verify);
 e=nvs_get_blob(h,"channels2",&verify,&len);
 if(e!=ESP_OK||len!=sizeof(verify)||memcmp(&verify,&before,sizeof(before))!=0){
  ESP_LOGW(TAG,"RC4: live NVS map changed; abort");
  nvs_close(h);return false;
 }
 e=nvs_set_blob(h,backup_key,&before,sizeof(before));
 if(e==ESP_OK)e=nvs_set_blob(h,"channels2",&after,sizeof(after));
 if(e==ESP_OK)e=nvs_commit(h);
 nvs_close(h);
 if(e!=ESP_OK){ESP_LOGE(TAG,"RC4: NVS migration failed %d",(int)e);return false;}
 return true;
}

static __attribute__((noinline)) bool m2s_rc4_migrate_known_channels() {
 if(!config_guard||!slot_store||!restart_timer||slots_corrupt)return false;
 if(!m2s_rc4_identified(9,"ALPSTUGA",M2sIkeaSensor::AirQuality) &&
    !m2s_rc4_identified(10,"MYGGBETT",M2sIkeaSensor::Contact))return false;
 const bool node2_absent=!known_node(2);
 const bool node7_absent=!known_node(7);
 xSemaphoreTake(config_guard,portMAX_DELAY);
 if(state.restart_required||slots_corrupt||slot_store->count!=11){
  xSemaphoreGive(config_guard);return false;
 }
 Rc42HeapStore before_buf,after_buf;
 if(!before_buf.ptr||!after_buf.ptr){
  ESP_LOGE(TAG,"RC42: migration store PSRAM allocation failed");
  xSemaphoreGive(config_guard);return false;
 }
 SlotStore &before=*before_buf.ptr;
 SlotStore &after=*after_buf.ptr;
 before=*slot_store;
 after=before;
 const auto &s5=before.slots[4], &s6=before.slots[5];
 const auto &s9=before.slots[8], &s10=before.slots[9];
 bool air=false,contact=false;
 const auto &a=before.slots;
 const bool common_map =
    a[0].node==4 && a[0].type==M2S_SUPLA_SENSOR_TH && a[0].endpoint==1 && a[0].aux_endpoint==2 && a[0].invert==0 &&
    a[1].node==3 && a[1].type==M2S_SUPLA_SENSOR_LEAK && a[1].endpoint==1 && a[1].aux_endpoint==1 && a[1].invert==0 &&
    a[2].node==5 && a[2].type==M2S_SUPLA_SENSOR_TH && a[2].endpoint==1 && a[2].aux_endpoint==2 && a[2].invert==0 &&
    a[6].node==8 && a[6].type==M2S_SUPLA_SENSOR_MOTION && a[6].endpoint==2 && a[6].aux_endpoint==2 && a[6].invert==0 &&
    a[7].node==9 && a[7].type==M2S_SUPLA_SENSOR_TH && a[7].endpoint==1 && a[7].aux_endpoint==1 && a[7].invert==0;
 if(!common_map){ESP_LOGW(TAG,"RC4: unexpected unaffected channel map; migration refused");xSemaphoreGive(config_guard);return false;}
 if(node2_absent &&
    ((before.slots[3].node==7 && before.slots[10].node==10) || (before.slots[3].node==10 && before.slots[10].node==7)) &&
    before.slots[3].type==M2S_SUPLA_SENSOR_CONTACT && before.slots[10].type==M2S_SUPLA_SENSOR_CONTACT &&
    before.slots[3].endpoint==1 && before.slots[10].endpoint==1 &&
    before.slots[3].aux_endpoint==1 && before.slots[10].aux_endpoint==1 &&
    before.slots[3].invert==0 && before.slots[10].invert==0 &&
    m2s_rc4_identified(9,"ALPSTUGA",M2sIkeaSensor::AirQuality) &&
    s5.node==2 && s5.type==M2S_SUPLA_SENSOR_CO2 &&
    s6.node==2 && s6.type==M2S_SUPLA_SENSOR_PM25 &&
    s9.node==9 && s9.type==M2S_SUPLA_SENSOR_CO2 &&
    s10.node==9 && s10.type==M2S_SUPLA_SENSOR_PM25 &&
    s5.endpoint==s9.endpoint && s5.aux_endpoint==s9.aux_endpoint &&
    s6.endpoint==s10.endpoint && s6.aux_endpoint==s10.aux_endpoint &&
    s5.invert==s9.invert && s6.invert==s10.invert){
   after.slots[4].node=9;after.slots[5].node=9;
   after.slots[8].node=2;after.slots[9].node=2;
   air=true;
 }
 const auto &s4=before.slots[3], &s11=before.slots[10];
 if(!air && node7_absent &&
    m2s_rc4_identified(10,"MYGGBETT",M2sIkeaSensor::Contact) &&
    s4.node==7 && s11.node==10 &&
    s4.type==M2S_SUPLA_SENSOR_CONTACT &&
    s11.type==M2S_SUPLA_SENSOR_CONTACT &&
    s4.endpoint==1 && s4.aux_endpoint==1 && s4.invert==0 &&
    s11.endpoint==s4.endpoint && s11.aux_endpoint==s4.aux_endpoint &&
    s11.invert==s4.invert){
   after.slots[3].node=10;
   after.slots[10].node=7;
   contact=true;
 }
 if(!air&&!contact){xSemaphoreGive(config_guard);return false;}
 const char *key=air?"rc4alpbackup":"rc4conbackup";
 const bool saved=m2s_rc4_commit_migration(before,after,key);
 if(saved){
  *slot_store=after;
  portENTER_CRITICAL(&mux);state.restart_required=true;portEXIT_CRITICAL(&mux);
  ESP_LOGW(TAG,"RC4: migrated %s map; NVS backup key=%s; reboot scheduled",
           air?"ALPSTUGA":"MYGGBETT",key);
  (void)esp_timer_start_once(restart_timer,3000000);
 }
 xSemaphoreGive(config_guard);
 return saved;
}

// RC4.4: retire ONLY the three confirmed re-pair duplicates at the end of
// the original 11-slot map. Historical slots 1..8 keep their exact positions.
// The map can grow normally again via the existing auto-discovery path.
static __attribute__((noinline)) bool m2s_rc44_retire_duplicate_tail() {
 if(!config_guard || !slot_store || !restart_timer || slots_corrupt ||
    !caption_registry_valid)return false;
 xSemaphoreTake(config_guard,portMAX_DELAY);
 if(state.restart_required || slot_store->count!=11) {
  xSemaphoreGive(config_guard);return false;
 }
 const auto &a=slot_store->slots;
 // Fail closed: this must be the verified map AFTER both old slots migrated.
 const bool exact=
  a[0].node==4 && a[0].type==M2S_SUPLA_SENSOR_TH && a[0].endpoint==1 && a[0].aux_endpoint==2 && a[0].invert==0 &&
  a[1].node==3 && a[1].type==M2S_SUPLA_SENSOR_LEAK && a[1].endpoint==1 && a[1].aux_endpoint==1 && a[1].invert==0 &&
  a[2].node==5 && a[2].type==M2S_SUPLA_SENSOR_TH && a[2].endpoint==1 && a[2].aux_endpoint==2 && a[2].invert==0 &&
  a[3].node==10 && a[3].type==M2S_SUPLA_SENSOR_CONTACT && a[3].endpoint==1 && a[3].aux_endpoint==1 && a[3].invert==0 &&
  a[4].node==9 && a[4].type==M2S_SUPLA_SENSOR_CO2 && a[4].endpoint==1 && a[4].aux_endpoint==1 && a[4].invert==0 &&
  a[5].node==9 && a[5].type==M2S_SUPLA_SENSOR_PM25 && a[5].endpoint==1 && a[5].aux_endpoint==1 && a[5].invert==0 &&
  a[6].node==8 && a[6].type==M2S_SUPLA_SENSOR_MOTION && a[6].endpoint==2 && a[6].aux_endpoint==2 && a[6].invert==0 &&
  a[7].node==9 && a[7].type==M2S_SUPLA_SENSOR_TH && a[7].endpoint==1 && a[7].aux_endpoint==1 && a[7].invert==0 &&
  a[8].node==2 && a[8].type==M2S_SUPLA_SENSOR_CO2 && a[8].endpoint==1 && a[8].aux_endpoint==1 && a[8].invert==0 &&
  a[9].node==2 && a[9].type==M2S_SUPLA_SENSOR_PM25 && a[9].endpoint==1 && a[9].aux_endpoint==1 && a[9].invert==0 &&
  a[10].node==7 && a[10].type==M2S_SUPLA_SENSOR_CONTACT && a[10].endpoint==1 && a[10].aux_endpoint==1 && a[10].invert==0;
 if(!exact || known_node(2) || known_node(7)) {
  xSemaphoreGive(config_guard);return false;
 }
 Rc42HeapStore before_buf,after_buf,verify_buf;
 if(!before_buf.ptr || !after_buf.ptr || !verify_buf.ptr) {
  ESP_LOGE(TAG,"RC44: PSRAM allocation failed; map unchanged");
  xSemaphoreGive(config_guard);return false;
 }
 SlotStore &before=*before_buf.ptr;
 SlotStore &after=*after_buf.ptr;
 SlotStore &verify=*verify_buf.ptr;
 before=*slot_store;
 after=before;
 after.count=8;
 for(unsigned i=8;i<11;i++)after.slots[i]=m2s_supla_sensor_slot_t{};
 CaptionRegistry cleaned=caption_registry;
 // Removed channel flags must not invalidate captions1 when count falls to 8.
 for(unsigned ch=9;ch<128;ch++){
  const unsigned byte=ch/8;
  const uint8_t bit=static_cast<uint8_t>(1u<<(ch%8));
  cleaned.pending[byte]&=static_cast<uint8_t>(~bit);
  cleaned.completed[byte]&=static_cast<uint8_t>(~bit);
 }
 nvs_handle_t h;
 esp_err_t e=nvs_open("m2s_ikea",NVS_READWRITE,&h);
 if(e!=ESP_OK){xSemaphoreGive(config_guard);return false;}
 size_t existing=0;
 const esp_err_t prior=nvs_get_blob(h,"rc44pretrim",nullptr,&existing);
 if(prior!=ESP_ERR_NVS_NOT_FOUND){
  ESP_LOGW(TAG,"RC44: pretrim backup exists/unreadable; no repeat");
  nvs_close(h);xSemaphoreGive(config_guard);return false;
 }
 size_t len=sizeof(verify);
 e=nvs_get_blob(h,"channels2",&verify,&len);
 if(e!=ESP_OK || len!=sizeof(verify) ||
    memcmp(&verify,&before,sizeof(before))!=0){
  ESP_LOGW(TAG,"RC44: saved NVS differs from live map; abort");
  nvs_close(h);xSemaphoreGive(config_guard);return false;
 }
 // One NVS commit: old map backup, trimmed map and cleaned caption flags.
 e=nvs_set_blob(h,"rc44pretrim",&before,sizeof(before));
 if(e==ESP_OK)e=nvs_set_blob(h,"channels2",&after,sizeof(after));
 if(e==ESP_OK)e=nvs_set_blob(h,"captions1",&cleaned,sizeof(cleaned));
 if(e==ESP_OK)e=nvs_commit(h);
 nvs_close(h);
 if(e!=ESP_OK){
  ESP_LOGE(TAG,"RC44: NVS trim aborted err=%d",(int)e);
  xSemaphoreGive(config_guard);return false;
 }
 *slot_store=after;
 caption_registry=cleaned;
 portENTER_CRITICAL(&mux);state.restart_required=true;portEXIT_CRITICAL(&mux);
 ESP_LOGW(TAG,"RC44: retired channels 9-11, preserved historical 1-8; future append enabled");
 const esp_err_t timer_err=esp_timer_start_once(restart_timer,3000000);
 if(timer_err!=ESP_OK)ESP_LOGE(TAG,"RC44: restart timer failed %d",(int)timer_err);
 xSemaphoreGive(config_guard);
 return true;
}

#endif

// RC47D_BATCH: owned exclusively by the network tick task.
static bool rc47d_inventory_valid=false;
static unsigned rc47d_unmapped=0;
static int64_t rc47d_first_slot_at=0;
static int64_t rc47d_pending_since=0;
static int64_t rc47d_last_add=0;
static int64_t rc47d_next_worker_try=0;

static __attribute__((noinline)) void m2s_supla_discover_all(){
 static int64_t next_check=0;
 const int64_t now=esp_timer_get_time();
 if(now<next_check)return;
 // Accelerate discovery only while inventory is incomplete. No new Matter
 // reads, tasks or simultaneous sessions are introduced.
 next_check=now+((!rc47d_inventory_valid||rc47d_unmapped)?500000LL:2000000LL);

 if(!config_guard||!slot_store||!restart_timer||slots_corrupt)return;
 m2s_supla_status_t st{};
 m2s_supla_status(&st);
 if(!st.enabled||!st.configured||st.restart_required)return;
 m2s_network_status_t net{};m2s_network_status(&net);
 m2s_matter_status_t ms{};m2s_matter_get_status(&ms);
 if(!ms.ready||ms.pair_busy||!net.connected||net.ap_active||net.testing)return;
 rc47d_inventory_valid=false;
#if M2S_RC4_ENABLE_MIGRATION
 // Run verified migrations before auto-discovery can append any new slots.
 if(st.online){
  if(m2s_rc4_migrate_known_channels())return;
  if(m2s_rc44_retire_duplicate_tail())return;
 }
#endif

 m2s_device_t *devices=static_cast<m2s_device_t *>(heap_caps_calloc(M2S_DEVICE_LIMIT,sizeof(m2s_device_t),MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT));
 if(!devices){ESP_LOGE(TAG,"RC41: device snapshot PSRAM allocation failed");return;}
 const size_t device_count=m2s_devices_snapshot(devices,M2S_DEVICE_LIMIT);
 SlotStore *next=make_store();
 if(!next){heap_caps_free(devices);return;}

 xSemaphoreTake(config_guard,portMAX_DELAY);
 if(state.restart_required||slots_corrupt||!config.enabled||!caption_registry_valid){
  xSemaphoreGive(config_guard);
  heap_caps_free(next);
  heap_caps_free(devices);
  return;
 }
 *next=*slot_store;
 const unsigned original_count=slot_store->count;
 xSemaphoreGive(config_guard);

 for(size_t i=0;i<device_count;i++){
  if(devices[i].state!=0&&devices[i].state!=2)continue;
  m2s_readings_t r{};
  if(!m2s_readings_cached(devices[i].node,&r))continue;
  m2s_supla_sensor_slot_t found[4]{};
  const unsigned count=m2s_stage11e_detect_slots(r,now,found,4);
  for(unsigned j=0;j<count;j++){
   const auto &slot=found[j];
   // S7.18 FIX: allow TH slot for primary ALPSTUGA node.
   bool exists=false;
   for(unsigned k=0;k<next->count;k++){
    if(next->slots[k].node==slot.node&&next->slots[k].type==slot.type){
     exists=true;break;
    }
   }
   if(exists||next->count>=M2S_SUPLA_EXTRA_LIMIT)continue;
   // Do not create another Cloud channel while a historical channel of the
   // same type points to a currently absent Matter node. Fail closed.
   if(m2s_rc4_has_orphan_of_type(slot.type,*next,devices,device_count)){
    static uint32_t warned_types=0;
    const uint32_t bit=(slot.type<32)?(1u<<slot.type):0u;
    if(bit && !(warned_types&bit)){
     warned_types|=bit;
     ESP_LOGW(TAG,"RC4_ORPHAN_GUARD type=%u candidate_node=%lu; auto-add deferred, NVS unchanged",
              (unsigned)slot.type,(unsigned long)slot.node);
    }
    continue;
   }
   next->slots[next->count++]=slot;
  }
 }

 // Coverage is based on saved slots or verified model, never a guessed name.
 unsigned missing=0;
 for(size_t i=0;i<device_count;i++){
  if(devices[i].state!=0&&devices[i].state!=2)continue;
  unsigned mapped=0;
  for(unsigned k=0;k<next->count;k++)if(next->slots[k].node==devices[i].node)++mapped;
  m2s_readings_t r{};
  const bool identified=m2s_readings_cached(devices[i].node,&r)&&r.vendor_valid&&r.product_valid;
  const auto model=identified?m2s_ikea_sensor(r.vendor_id,r.product_id):M2sIkeaSensor::Unknown;
  if(identified&&model==M2sIkeaSensor::Unknown)continue;
  const unsigned expected=model==M2sIkeaSensor::AirQuality?3u:1u;
  if(mapped<expected)++missing;
 }
 heap_caps_free(devices);
 xSemaphoreTake(config_guard,portMAX_DELAY);
 if(state.restart_required||slots_corrupt||!config.enabled||!caption_registry_valid||
    slot_store->count!=original_count){
  xSemaphoreGive(config_guard);
  heap_caps_free(next);
  return;
 }

 // Protect against concurrent manual channel changes.
 if(memcmp(next->slots,slot_store->slots,
           slot_store->count*sizeof(m2s_supla_sensor_slot_t))!=0){
  xSemaphoreGive(config_guard);
  heap_caps_free(next);
  return;
 }
 if(next->count==original_count){
  rc47d_unmapped=missing;rc47d_inventory_valid=true;
  static int64_t next_batch_log=0;
  if(now>=next_batch_log){
   next_batch_log=now+10000000LL;
   ESP_LOGI(TAG,"RC47D_BATCH slots=%u pending_nodes=%u worker=%d",original_count,missing,(int)rc47d_worker_started);
  }
  xSemaphoreGive(config_guard);heap_caps_free(next);return;
 }
 if(heap_caps_get_free_size(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT)<10000||
    heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT)<1600){
  xSemaphoreGive(config_guard);
  heap_caps_free(next);
  return;
 }

 // Only newly appended channels receive one-time caption permission.
 CaptionRegistry next_captions=caption_registry;
 for(unsigned channel=original_count+1;channel<=next->count;channel++){
  const unsigned byte=channel/8;
  const uint8_t bit=static_cast<uint8_t>(1u<<(channel%8));
  next_captions.pending[byte]|=bit;
  next_captions.completed[byte]&=static_cast<uint8_t>(~bit);
 }
 next_captions.pending[0]&=static_cast<uint8_t>(~1u);

 nvs_handle_t h;
 esp_err_t e=nvs_open("m2s_ikea",NVS_READWRITE,&h);
 if(e==ESP_OK){
  e=nvs_set_blob(h,"channels2",next,sizeof(*next));
  if(e==ESP_OK)
   e=nvs_set_blob(h,"captions1",&next_captions,sizeof(next_captions));
  if(e==ESP_OK)e=nvs_commit(h);
  nvs_close(h);
 }
 if(e==ESP_OK){
  caption_registry=next_captions;
  SlotStore *old=slot_store;
  slot_store=next;
  heap_caps_free(old);
  rc47d_unmapped=missing;rc47d_inventory_valid=true;
  if(rc47d_worker_started){
   if(!rc47d_pending_since)rc47d_pending_since=now;
   rc47d_last_add=now;
  }
  ESP_LOGI(TAG,"RC47D_BATCH slots=%u pending_nodes=%u worker=%d",(unsigned)slot_store->count,missing,(int)rc47d_worker_started);
    ESP_LOGI(TAG,"RC47D2_FAST_MAP saved %u channels",
             (unsigned)slot_store->count);
    for(unsigned i=original_count;i<slot_store->count;i++){
      const auto &added=slot_store->slots[i];
      ESP_LOGI(TAG,"SUPLA_DISCOVER_ADD channel=%u node=%lu type=%u ep=%u",
               i+1,(unsigned long)added.node,(unsigned)added.type,(unsigned)added.endpoint);
    }
    // RC47D: keep collecting; restart only once the batch is ready or its deadline expires.
 }else {ESP_LOGE(TAG,"RC47D_BATCH_SAVE_FAILED err=%d",(int)e);heap_caps_free(next);}
 xSemaphoreGive(config_guard);
}

extern "C" void m2s_supla_tick(){
 // Preserve the legacy ALPSTUGA migration and manual configuration restart.
 m2s_supla_alpstuga_auto();
 if(!config_guard)return;
 m2s_network_status_t net{};m2s_network_status(&net);
 m2s_matter_status_t ms{};m2s_matter_get_status(&ms);
 // Start SNTP while AP grace / Matter startup runs, but only for configured SUPLA.
 static bool early_clock_started=false;
 m2s_supla_status_t ss{};m2s_supla_status(&ss);
 if(!early_clock_started && net.connected && !net.testing && ss.enabled && ss.configured){
   if(!esp_sntp_enabled()){
     esp_sntp_setoperatingmode(SNTP_OPMODE_POLL);
     esp_sntp_setservername(0,"time.cloudflare.com");esp_sntp_init();
   }
   early_clock_started=true;
   ESP_LOGI(TAG,"RC47D4_CLOCK_START uptime_ms=%lld",(long long)(esp_timer_get_time()/1000));
 }
 if(!ms.ready||ms.pair_busy||!net.connected||net.ap_active||net.testing||m2s_ble_scan_active())return;
 m2s_supla_discover_all();
 const int64_t now=esp_timer_get_time();
 xSemaphoreTake(config_guard,portMAX_DELAY);
 const bool enabled=config.enabled&&config.node&&!slots_corrupt&&!state.restart_required&&slot_store;
 if(!enabled){xSemaphoreGive(config_guard);return;}

 if(rc47d_worker_started){
  if(rc47d_pending_since && restart_timer &&
     ((rc47d_inventory_valid && rc47d_unmapped==0) ||
      now-rc47d_last_add>=15000000LL || now-rc47d_pending_since>=45000000LL)){
   const esp_err_t e=esp_timer_start_once(restart_timer,2000000);
   if(e==ESP_OK){
    portENTER_CRITICAL(&mux);state.restart_required=true;portEXIT_CRITICAL(&mux);
    ESP_LOGI(TAG,"RC47D_BATCH_RESTART slots=%u pending_nodes=%u",(unsigned)slot_store->count,rc47d_unmapped);
   }else ESP_LOGE(TAG,"RC47D_BATCH_TIMER_FAILED err=%d",(int)e);
  }
  xSemaphoreGive(config_guard);return;
 }
 // Existing verified slots are usable before any new Matter measurements.
 // Never register zero channels; wait for first verified slot on fresh setup.
 const unsigned slots=slot_store->count;
 if(!slots || now<rc47d_next_worker_try){xSemaphoreGive(config_guard);return;}
 // No fixed boot delay. Protect the TLS worker and radio from low SRAM.
 const unsigned free=heap_caps_get_free_size(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT);
 const unsigned dma=heap_caps_get_free_size(MALLOC_CAP_DMA);
 const unsigned largest=heap_caps_get_largest_free_block(MALLOC_CAP_DMA);
 if(free<45000 || dma<28000 || largest<16000){
   rc47d_next_worker_try=now+1000000LL;
   ESP_LOGW(TAG,"RC47D4_RAM_WAIT free=%u dma=%u largest=%u",free,dma,largest);
   xSemaphoreGive(config_guard);return;
 }
 // On first installation allow a 2s coalescing window for fresh slots only.
 // Saved boot slots bypass that window (set below during init).
 if(!rc47d_first_slot_at)rc47d_first_slot_at=now;
 if(!rc47d_boot_has_slots && (!rc47d_inventory_valid || rc47d_unmapped)){
   if(now-rc47d_first_slot_at<2000000LL){xSemaphoreGive(config_guard);return;}
 }
 ESP_LOGI(TAG,"RC47D4_START slots=%u pending_nodes=%u uptime_ms=%lld free=%u dma=%u",slots,rc47d_unmapped,(long long)(now/1000),free,dma);
 // Claim while holding the same mutex as configure; worker copies config under it.
 if(xTaskCreate(worker,"m2s_supla",8192,nullptr,2,nullptr)==pdPASS){
   rc47d_worker_started=true;xSemaphoreGive(config_guard);
 }else{
   rc47d_next_worker_try=now+1000000LL;xSemaphoreGive(config_guard);
   info(-103,"Brak pamieci na zadanie SUPLA");
 }
}
