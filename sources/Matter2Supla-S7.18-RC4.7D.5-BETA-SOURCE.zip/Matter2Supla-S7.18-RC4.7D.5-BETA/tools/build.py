"""Build the RC4.7D.5 firmware in an activated ESP-IDF and ESP-Matter environment."""

from pathlib import Path
import argparse
import os
import shutil
import subprocess
import sys

from rebuild_panel import rebuild_panel


def main() -> None:
    parser = argparse.ArgumentParser(description="Zbuduj APP i obraz FULL dla ESP32-C5.")
    parser.add_argument("variant", choices=("N16R8", "N32R8"))
    parser.add_argument("--build-dir", type=Path, help="Osobny katalog tego wariantu kompilacji")
    args = parser.parse_args()
    project = Path(__file__).resolve().parents[1]
    sdk = os.environ.get("IDF_PATH")
    if not sdk or not os.environ.get("ESP_MATTER_PATH"):
        parser.error("Aktywuj środowiska ESP-IDF i ESP-Matter zgodnie z README.md.")
    output = (args.build_dir or project / ("build-" + args.variant.lower())).resolve()
    output.mkdir(parents=True, exist_ok=True)
    config = output / "sdkconfig"
    if not config.exists():
        shutil.copyfile(project / "configs/RC47D5" / ("sdkconfig." + args.variant.lower()), config)
    expected_size = {"N16R8": "16MB", "N32R8": "32MB"}[args.variant]
    if f'CONFIG_ESPTOOLPY_FLASHSIZE="{expected_size}"' not in config.read_text().splitlines():
        parser.error(f"Katalog kompilacji musi zawierać konfigurację wariantu {args.variant}.")
    rebuild_panel(project)
    command = [sys.executable, str(Path(sdk) / "tools/idf.py"), "-B", str(output),
               "-DIDF_TARGET=esp32c5", f"-DSDKCONFIG={config}", "merge-bin",
               "-o", f"Matter2Supla-{args.variant}-FULL-0x0.bin"]
    subprocess.run(command, cwd=project, check=True)
    print(output / "esp_ot_br.bin")
    print(output / f"Matter2Supla-{args.variant}-FULL-0x0.bin")


if __name__ == "__main__":
    main()
