# Matter2Supla S7.18 RC4.7D.5 BETA

Źródła bramki Matter over Thread → SUPLA dla ESP32-C5 z 8 MB PSRAM. Warianty N16R8 i N32R8 mają odpowiednio 16 i 32 MB pamięci flash. Katalog `main` zawiera aplikację, panel WWW, odczyty Matter, BLE i obsługę sieci. `components/m2s_supla` obsługuje połączenie z SUPLA i mapowanie kanałów. Użyty kod biblioteki SUPLA wraz z lokalnymi zmianami znajduje się w `vendor/supla-device`.

[Wydanie i oryginalne binarki](https://github.com/krzychunh/Matter2Supla-Releases/releases/tag/v0.9.3-s7.18-rc4.7d.5-beta)

## Wersje zależności

| Składnik | Rewizja źródłowa |
| --- | --- |
| ESP-IDF v5.5.6 | [880a203ae603d08a94d06aa01e0d6761958e5e9e](https://github.com/espressif/esp-idf/tree/880a203ae603d08a94d06aa01e0d6761958e5e9e) |
| ESP-Matter | [7ab5228aa238e837e948e840c380e8beb601db9a](https://github.com/espressif/esp-matter/tree/7ab5228aa238e837e948e840c380e8beb601db9a) |
| ConnectedHomeIP | [9c2a63634e880b92e29b25a49543b70a4baf1572](https://github.com/project-chip/connectedhomeip/tree/9c2a63634e880b92e29b25a49543b70a4baf1572) |
| Baza dołączonej biblioteki SUPLA | [ec030da92909a3fd38a5b3fcc5f1c6bffe0c89b0](https://github.com/SUPLA/supla-device/tree/ec030da92909a3fd38a5b3fcc5f1c6bffe0c89b0) |

`dependencies.lock.in` zapisuje wersje i sumy komponentów rejestru Espressif. CMake wpisuje aktualną ścieżkę do ESP-IDF w kopii tego pliku w katalogu kompilacji. Poprawki do ESP-Matter i ConnectedHomeIP są w `patches/RC47D5`. Adresy wersji komponentów rejestru podaje [wykaz zależności](docs/RC47D5/KOMPONENTY.md). Dwa publiczne certyfikaty CA używane przez CMake biblioteki SUPLA pochodzą z jej wskazanej wyżej rewizji.

## Przygotowanie na Linux lub w WSL Ubuntu

Zacznij w rozpakowanym katalogu zawierającym ten plik. Używaj jednej sesji Bash. Poniższe polecenia tworzą nowe katalogi SDK pod `m2s-rc47d5-sdk` w katalogu domowym. Wymagają narzędzi programistycznych dla Linux opisanych w dokumentacji Espressif i dostępu do repozytoriów zależności.

[Wymagania ESP-IDF dla Linux](https://docs.espressif.com/projects/esp-idf/en/v5.5.6/esp32c5/get-started/linux-macos-setup.html) · [Przygotowanie środowiska ESP-Matter](https://docs.espressif.com/projects/esp-matter/en/latest/esp32/developing.html)

1. Zapamiętaj lokalizację źródeł i utwórz katalog na SDK.

   ```bash
   export M2S_PROJECT="$PWD" M2S_SDK="$HOME/m2s-rc47d5-sdk" && mkdir -p "$M2S_SDK"
   ```

2. Pobierz ESP-IDF, zainstaluj narzędzia dla C5 i aktywuj środowisko.

   ```bash
   git clone --branch v5.5.6 --depth 1 --shallow-submodules --recurse-submodules https://github.com/espressif/esp-idf.git "$M2S_SDK/esp-idf" && test "$(git -C "$M2S_SDK/esp-idf" rev-parse HEAD)" = 880a203ae603d08a94d06aa01e0d6761958e5e9e && "$M2S_SDK/esp-idf/install.sh" esp32c5 && . "$M2S_SDK/esp-idf/export.sh"
   ```

3. Pobierz dokładne wersje ESP-Matter, ConnectedHomeIP i podmodułów dla tej platformy.

   ```bash
   git init -q "$M2S_SDK/esp-matter" && git -C "$M2S_SDK/esp-matter" remote add origin https://github.com/espressif/esp-matter.git && git -C "$M2S_SDK/esp-matter" fetch --depth 1 origin 7ab5228aa238e837e948e840c380e8beb601db9a && git -C "$M2S_SDK/esp-matter" checkout --detach FETCH_HEAD && git -C "$M2S_SDK/esp-matter" submodule update --init --depth 1
   ```

   ```bash
   export M2S_CHIP="$M2S_SDK/esp-matter/connectedhomeip/connectedhomeip" && test "$(git -C "$M2S_CHIP" rev-parse HEAD)" = 9c2a63634e880b92e29b25a49543b70a4baf1572 && (cd "$M2S_CHIP" && python3 scripts/checkout_submodules.py --platform esp32 linux --shallow)
   ```

4. Na czystych kopiach SDK zastosuj obie poprawki jeden raz. Następnie przygotuj narzędzia Matter.

   ```bash
   git -C "$M2S_SDK/esp-matter" apply "$M2S_PROJECT/patches/RC47D5/01-esp-matter.patch" && git -C "$M2S_CHIP" apply "$M2S_PROJECT/patches/RC47D5/02-connectedhomeip.patch" && (cd "$M2S_SDK/esp-matter" && ./install.sh --no-host-tool) && . "$M2S_SDK/esp-matter/export.sh"
   ```

W kolejnej sesji ustaw ponownie `M2S_SDK` i aktywuj już zainstalowane środowiska.

```bash
export M2S_SDK="$HOME/m2s-rc47d5-sdk" && . "$M2S_SDK/esp-idf/export.sh" && . "$M2S_SDK/esp-matter/export.sh"
```

## Kompilacja

Uruchom polecenie z katalogu projektu. Pierwsza kompilacja pobiera komponenty. Każdy wariant ma osobny katalog wynikowy i kopię konfiguracji, którą można później edytować.

```bash
python3 tools/build.py N16R8
```

```bash
python3 tools/build.py N32R8
```

| Wynik | Miejsce docelowe |
| --- | --- |
| `build-n16r8/esp_ot_br.bin` lub `build-n32r8/esp_ot_br.bin` | Aplikacja pod adres `0x20000` |
| `build-n16r8/Matter2Supla-N16R8-FULL-0x0.bin` lub `build-n32r8/Matter2Supla-N32R8-FULL-0x0.bin` | Pełny obraz od `0x0` |

W obu oficjalnych obrazach znajduje się partycja `factory` od `0x20000` o rozmiarze 8 MiB. Odpowiada jej tablica `partitions_32mb.csv` używana także w profilu N16R8. Przy wgrywaniu obrazu FULL obszar NVS z konfiguracją i parowaniami zostaje nadpisany. Polecenia aktualizacji i instalacji są w instrukcji wydania.

[Instrukcja instalacji](https://github.com/krzychunh/Matter2Supla-Releases/blob/main/INSTALL.md)

## Pochodzenie źródeł

Eksport opiera się na zapisie źródeł wydania `968febc063b9821069213c14c01353d80a8fea9f`. Konfiguracje publiczne mają puste pole przykładowego SSID, a stopka panelu prowadzi do strony projektu. Kod HTML panelu można edytować w `main/m2s_web.cpp`. Skrypt kompilacji odtwarza z niego `main/m2s_web_panel_gzip.inc`.

Sumy w `docs/RC47D5/SHA256SUMS.txt` identyfikują cztery opublikowane pliki BIN. Data i godzina kompilacji oraz opisana zmiana stopki wpływają na bajty własnego obrazu.

## Licencje

Kod własny Matter2Supla w tym wydaniu i program jako całość są udostępnione na warunkach GNU General Public License w wersji 3. Pełny tekst znajduje się w `COPYING`. Komponenty zewnętrzne zachowują własne informacje o prawach autorskich i licencjach. Biblioteka AC SOFTWARE zawiera oznaczenia `GPL-2.0-or-later` i plik `vendor/supla-device/LICENSE`. Teksty licencji Apache-2.0 i CC0-1.0 znajdują się w `LICENSES`. Oznaczenia w konkretnych plikach określają warunki dla tych plików.
